package sistema;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Clase para manejar las reservas de nuestro sistema.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Reserva implements Serializable{

	private static final long serialVersionUID = 1066957842465438809L;
	
	private UsuarioRegistrado _usuario;
	private LocalDate _fechaIniReserva;
	private LocalDate _fechaFinReserva;
	
	/**
	 * Constructor de las reservas, que contendr�n los datos principales.
	 * 
	 * @param usuario, usuarioRegistrado.
	 * @param fechaIni, fecha inicio reserva.
	 */
	public Reserva(UsuarioRegistrado usuario, LocalDate fechaIni) {
		
		_usuario = usuario;
		_fechaIniReserva = fechaIni;
		_fechaFinReserva = _fechaIniReserva.plusDays(5);
	}
	
	/**
	 * Devuelve el usuario de la oferta.
	 * 
	 * @return usuario registrado propietario de la reserva.
	 */
	public UsuarioRegistrado getUsuarioReserva() {
		return _usuario;
	}
	
	/**
	 * Devuelve la fecha de inicio de la reserva.
	 * 
	 * @return fecha inicio reserva.
	 */
	public LocalDate getFechaIniReserva() {
		return _fechaIniReserva;
	}
	
	/**
	 * Devuelve la fecha l�mite de la reserva (Inicial + 5 d�as).
	 * 
	 * @return fecha final de la reserva.
	 */
	public LocalDate getFechaFinReserva() {
		return _fechaFinReserva;
	}
	
	/**
	 * Comprueba si la fecha l�mite ha sido excedida.
	 * 
	 * @param fechaActual, fecha de cuando se comprueba si la fecha l�mite ha sido excedida.
	 * 
	 * @return true si ha sido excedida, false si no.
	 */
	public Boolean isFechaLimiteExcedida(LocalDate fechaActual) { 
		System.out.println(fechaActual.getDayOfYear());
		System.out.println(_fechaFinReserva.getDayOfYear());
		if(fechaActual.isAfter(_fechaFinReserva)) {
			return true;
		}	
		return false;
	 } 
}
