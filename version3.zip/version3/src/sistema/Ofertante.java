package sistema;

import java.util.*;

/**
 * Clase para manejar los usuarios registrados con caracter�sticas de Ofertante.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Ofertante extends Perfil{

	private static final long serialVersionUID = -8471664018925403169L;
	
	private ArrayList<Vivienda> listaViviendas = new ArrayList<Vivienda>();
	private ArrayList<String> buzon = new ArrayList<String>();
	
	/**
	 * Constructor del perdil tipo ofertante, crea un perfil con un array de viviendas.
	 */
	public Ofertante () {
		super("Ofertante");
	}
	
	/**
	 * Obtiene la lista de viviendas que tiene un ofertante.
	 * 
	 * @return la lista de viviendas del ofertante.
	 */
	public ArrayList<Vivienda> getViviendas() {
		return listaViviendas;
	}
	
	/**
	 * Obtiene la lista de mensajes en el buzon que tiene un ofertante.
	 * 
	 * @return la lista de mensajes del buzon del ofertante.
	 */
	public ArrayList<String> getBuzon() {
		return buzon;
	}
	
	/**
	 * Obtiene una vivienda en concreto.
	 * 
	 * @param v1, vivienda a ver si pertenece a un ofertante.
	 * 
	 * @return la lista de viviendas del ofertante.
	 */
	public Vivienda getViviendaConcreta(Vivienda v1) {
		
		for(int i = 0; i< listaViviendas.size(); i++) {
			if(listaViviendas.get(i).equals(v1)) {
				return listaViviendas.get(i);
			}
		}
		return null;
	}
	/**
	 * A�ade una sugerencia al buz�n.
	 * 
	 * @param sugerencia, sugerencia de modificaci�n.
	 */
	public void a�adirSugerencia(String sugerencia) {
		buzon.add(sugerencia);
	}
	
	/**
	 * A�ade una vivienda a la lista de viviendas de un ofertante
	 * 
	 * @param v1, vivienda que se va a a�adir.
	 */
	public void a�adirVivienda(Vivienda v1) {
		listaViviendas.add(v1);
	}
	
	/**
	 * Comprueba si una vivienda es de un ofertante concreto.
	 * 
	 * @param v1, vivienda que se quiere saber si es del ofertante o no.
	 * @param o1, ofertante en concreto.
	 * 
	 * @return true si la vivienda pertenece al ofertante, false si no.
	 */
	public Boolean viviendaDeOfertante(Vivienda v1, Ofertante o1) {	
		
		for(int i=0; i<o1.listaViviendas.size(); i++) {
			if(o1.listaViviendas.get(i).equals(v1)) {
				return true;
			}			
		}	
		return false;
	}
	
	public void anadirSugerenciaBuzon(String sugerencia) {
		buzon.add(sugerencia);
	}
}
