package sistema;

import java.util.ArrayList;

/**
 * Clase para manejar los usuarios registrados con caracter�sticas de Demandante.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Demandante extends Perfil{
	
	private static final long serialVersionUID = 7316459827369800371L;
	
	private ArrayList<Oferta> listaOfertasContratadas = new ArrayList<Oferta>();
	private ArrayList<Oferta> listaOfertasReservadas = new ArrayList<Oferta>();
	
	/**
	 * Constructor de demandante, crea un tipo perfil con la palabra demandante.
	 * 
	 */
	public Demandante() {
		super("Demandante");
	}
	
	/**
	 * A�ade una oferta contratada.
	 * 
	 * @param o1, oferta contratada.
	 */	
	public void a�adirOfertaContratada(Oferta o1) {
		listaOfertasContratadas.add(o1);
	}
	
	/**
	 * A�ade una oferta reservada.
	 * 
	 * @param o1, oferta reservada.
	 */	
	public void a�adirOfertaReservada(Oferta o1) {
		listaOfertasReservadas.add(o1);
	}
	
	
	/**
	 * Devuelve un array de las ofertas contratadas por un demandante.
	 * 
	 * @return las ofertas contratadas
	 */
	public ArrayList<Oferta> getOfertasContratadas() {
		return listaOfertasContratadas;
	}
	
	/**
	 * Devuelve un array de las ofertas reservadas por un demandante.
	 * 
	 * @return las ofertas reservadas.
	 */
	public ArrayList<Oferta> getOfertasReservadas() {
		return listaOfertasReservadas;
	}
	
	/**
	 * Obtiene una oferta contratada concreta.
	 * 
	 * @param o1, oferta a buscar.
	 * 
	 * @return oferta concreta..
	 */	
	public Oferta getOfertaContratada(Oferta o1) {
		for(int i = 0; i<listaOfertasContratadas.size(); i++) {
			if(listaOfertasContratadas.get(i).equals(o1)) {
				return listaOfertasContratadas.get(i);
			}
		}
		return null;
	}
}
