package sistema;

import java.io.Serializable;
import java.util.*;

/**
 * Clase que maneja las viviendas de nuestro sistema.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 */
public class Vivienda implements Serializable {
	
	private static final long serialVersionUID = -8626909831736277986L;
	
	ArrayList<Oferta> _ofertasVivienda = new ArrayList<Oferta>();
	private String _descripcion;
	private String _direccion;
	private UsuarioRegistrado _duenio;
	private int _codigoPostal;
	
	/**
	 * Constructor de viviendas, que establece los datos principales de las viviendas.
	 * 
	 * @param descripcion_, descripcion de la vivienda.
	 * @param direccion_, direccion de la vivienda.
	 * @param duenio_, el usuario due�o de la vivienda.
	 * @param cp_, el codigo postal.
	 * 	 
	 */
	public Vivienda (String descripcion_, String direccion_, UsuarioRegistrado duenio_, int cp_) {
		_direccion = direccion_;
		_descripcion = descripcion_;
		_duenio = duenio_;
		_codigoPostal = cp_;
	}
	
	/**
	 * A�ade una oferta a la lista de ofertas de una vivienda.
	 * 
	 * @param o1, oferta a a�adir.
	 * 
	 */
	public void a�adirOferta(Oferta o1) {
		_ofertasVivienda.add(o1);
	}
	
	/**
	 * Obtiene una oferta en concreto.
	 * 
	 * @param o1, oferta a a�adir.
	 * 
	 * @return la oferta en concreto devuelta del array de ofertas de una vivienda.
	 * 
	 */
	public Oferta getOfertaConcreta(Oferta o1) {
		for(int i = 0; i<_ofertasVivienda.size(); i++) {
			if(_ofertasVivienda.get(i).equals(o1)) {
				return _ofertasVivienda.get(i);
			}
		}
		return null;
	}
	
	/**
	 * Obtiene el codigo postal de una vivienda.
	 * 
	 * @return codigo postal.
	 */
	public int getCodigoPostal() {
		return _codigoPostal;
	}
	
	/**
	 * Obtiene un usuario registrado, que es el due�o de una vivienda.
	 * 
	 * @return due�o de la vivienda.
	 */
	public UsuarioRegistrado getDuenio() {
		return _duenio;
	}
	
	/**
	 * Obtiene la descripci�n de una vivienda.
	 * 
	 * @return descripci�n de la vivienda.
	 */
	public String getDescripcionVivienda() {
		return _descripcion;
	}
	
	/**
	 * Obtiene la direcci�n de una vivienda.
	 * 
	 * @return direccion;
	 */
	public String getDireccionVivienda() {
		return _direccion;
	}
	
	/**
	 * Obtiene la lista de ofertas que tiene una vivienda.
	 * 
	 * @return lista ofertas vivienda.
	 */
	public ArrayList<Oferta> getOfertasVivienda() {
		return _ofertasVivienda;
	}
}