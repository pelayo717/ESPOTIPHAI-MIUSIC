package sistema;

import java.io.Serializable;

/**
 * Clase abstracta para manejar las valoraciones de tipo comentario y tipo num�rico.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 */

public abstract class Valoracion implements Serializable{
	
	private static final long serialVersionUID = 7728260235283665650L;
	
	private UsuarioRegistrado _usuario;
	
	public void a�adirValoracion(Valoracion v1) {

	}
	/**
	 * Obtiene el autor de la valoraci�n.
	 * 
	 * @return el usuario que ha hecho la valoracion.
	 */	
	public UsuarioRegistrado getUsuarioValoracion() {
		return _usuario;
	}
	
	/**
	 * Fija el autor de la valoraci�n.
	 * 
	 * @param usuario_, usuario registrado que es autor de la valoraci�n.
	 */	
	public void setUsuarioValoracion(UsuarioRegistrado usuario_) {
		_usuario = usuario_;
	}
		
}