package sistema;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Clase para manejar los usuarios registrados y sus datos principales.
 * 
 * @author Nazariy Gunko
 * @author Alvaron Mor�n
 *
 */
public class UsuarioRegistrado implements Serializable{

	private static final long serialVersionUID = 495164078125808211L;
	
	private String _tarjetaCredito;
	private String _nombre;
	private String _apellidos;
	private String _dni;
	private String _contrasenia;
	private Boolean _bloqueado;
	private Perfil[] perfiles = new Perfil[2];
	private ArrayList<String> _sugerenciasOfertas = new ArrayList<String>();
	
	
	/**
	 * Constructor de usuarios registrados, que los inicializa con los datos principales de un usuario registrado.
	 * 
	 * @param letra, letra representando el tipo de perfil que tienen.
	 * @param nombre_, nombre del usuario registrado.
	 * @param apellidos_, apellidos del usuario registrado.
	 * @param tarjeta_, tarjeta de credito del usuario registrado.
	 * @param dni_, dni del usuario registrado.
	 * @param contrasenia_, contrase�a del usuario registrado.
	 * @param bloq_, bloqueado 0 si no est� bloqueado, 1 si lo est�.
	 *
	 */
	public UsuarioRegistrado(String letra, String nombre_, String apellidos_, String tarjeta_, String dni_, String contrasenia_, int bloq_) {
		_nombre = nombre_;
		_apellidos = apellidos_;
		_tarjetaCredito = tarjeta_;
		_dni = dni_;
		_contrasenia = contrasenia_;
		if(bloq_ == 1) {
			setUsuarioBloqueado();
		} else if(bloq_ == 0) {
			setUsuarioNoBloqueado();
		}
		
		if(letra.equalsIgnoreCase("O")) {
			perfiles[0] = new Ofertante();
		} else if(letra.equalsIgnoreCase("D")) {
			perfiles[0] = new Demandante();
		} else if(letra.equalsIgnoreCase("OD")) {
			perfiles[0] = new Ofertante();
			perfiles[1] = new Demandante();
		}
	}
	
	
	/**
	 * Convierte todos los datos del usuario registrado a un String para ser imprimido.
	 * 
	 * @return o con lso datos principales.
	 */
	public String toString() { 
		String o = "", aux1="", aux2="";
		
		if(perfiles[0] == null) {
			aux1 = "";
		} else {
			aux1 = perfiles[0].toString();
		}
		if(perfiles[1] == null) {
			aux2 ="";
		} else {
			aux2 = perfiles[1].toString();
		}
		
		o = o + _nombre + " " + _apellidos + ", con perfil tipo " + aux1 + aux2 + ".\nCon DNI " + _dni + " y n�mero de tarjeta de cr�dito " + 
		_tarjetaCredito + " tiene de contrase�a la palabra \"" + _contrasenia + "\"";
		
		return o;
	}
	
	
	/**
	 * Establece la tarjeta de credito de un usuario.
	 * 
	 * @param tcredito, la nueva tarjeta de credito.
	 */
	public void setTarjetaCredito(String tcredito) {
		_tarjetaCredito = tcredito;
	}
	
	/**
	 * Devuelve el dni de un usuario registrado.
	 * 
	 * @return dni.
	 */
	public String getDni() {
		return _dni;
	}
	
	/**
	 * Devuelve la contrase�a de un usuario registrado.
	 * 
	 * @return contrse�a.
	 */
	public String getContrasenia() {
		return _contrasenia;
	}
	
	/**
	 * Devuelve si un usuario est� bloqueado o no.
	 * 
	 * @return true o false.
	 */
	public Boolean getBloqueado() {
		return _bloqueado;
	}
	
	/**
	 * Obtiene la tarjeta de credito del usuario registrado.
	 * 
	 * @return tarjeta de credito.
	 */
	public String getTarjetaCredito() {
		return _tarjetaCredito;
	}
	
	/**
	 * Devuelve el nombre del usuario registrado.
	 * 
	 * @return string con el nombre del usuario.
	 */
	public String getNombre() {
		return _nombre; 
	}
	
	/**
	 * Devuelve los apellidos de un usuario.
	 * @return String con los apellidos del usuario.
	 */
	public String getApellidos() {
		return _apellidos;
	}
	
	/**
	 * Establece el valor del campo bloqueado de usuario registrado a true.
	 */
	public void setUsuarioBloqueado() {
		_bloqueado = true;
	}
	
	/**
	 * Establece el valor del campo bloqueado de usuario registrado a false.
	 */
	public void setUsuarioNoBloqueado() {
		_bloqueado = false;
	}
	
	/**
	 * Obtiene el array de perfiles de un usuarioREgistrado.
	 * 
	 * @return array de perfiles..
	 */
	public Perfil[] tipoPerfil() {
		return perfiles;
	}

	/**
	 * Devuelve el perfil de demandante de un usuario registrado.
	 * 
	 * @return perfil de demandante, o null si no hay un perfil de demandante.
	 */
	public Perfil perfilDemandante() {
		if(perfiles[0] instanceof Demandante) {
			return (Demandante)perfiles[0];
		} else if (perfiles[1] instanceof Demandante) {
			return (Demandante)perfiles[1];
		}	
		return null;
	}
		
	/**
	 * Evualua si el usuario registrado tiene un perfil de tipo ofertante.
	 * 
	 * @return true si tiene perfil de tipo ofertante, false si no.
	 */
	public Boolean tienePerfilOfertante() {
		if(perfiles[0] instanceof Ofertante) {
			return true;
		} else if (perfiles[1] instanceof Ofertante) {
			return true;
		}	
		return false;
	}
	
	/**
	 * A�adie una sugerencia al array de sugerencias de un usuario.
	 * 
	 * @param sugerencia a realizar cambio.
	 */
	public void anadirSugerencia(String sugerencia) {
		_sugerenciasOfertas.add(sugerencia);
	}
	
	/**
	 * Evalua si el usuario registrado tiene un perfil de tipo demandante.
	 * 
	 * @return true si tiene perfil de tipo demandante, false si no.
	 */
	public Boolean tienePerfilDemandante() {
		if(perfiles[0] instanceof Demandante) {
			return true;
		} else if (perfiles[1] != null) {
			if(perfiles[1] instanceof Demandante) {
				return true;
			}
		}	
		return false;
	}
	
	/**
	 * Obitne el perfil de tipo demandante si es que el usuario registrado tiene.
	 * 
	 * @return perfil de tipo demandante del usuario registrado, null si no tiene.
	 */
	public Perfil getPerfilDemandante() {
			if (perfiles[0] instanceof Demandante) {
				return (Demandante)perfiles[0];
			}
			if (perfiles[1] != null) {
				if (perfiles[1] instanceof Demandante) {
					return (Demandante)perfiles[1];
				}
			}
			return null;
	}
	
	/**
	 * Devuelve el perfil de ofertante de un usuario registrado.
	 * 
	 * @return perfil de ofertante, o null si no hay un perfil de ofertante.
	 */
	public Perfil getPerfilOfertante() {
			if (perfiles[0] instanceof Ofertante) {
				return (Ofertante)perfiles[0];
			}
			return null;
	}
}
