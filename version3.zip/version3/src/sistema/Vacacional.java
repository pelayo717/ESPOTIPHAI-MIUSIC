package sistema;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Clase para manejar las Ofertas de tipo vacacional.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Vacacional extends Oferta {
	
	private static final long serialVersionUID = 8047924157978478926L;
	
	private LocalDate _fechaInicio;
	private LocalDate _fechaFin;
	private int _precioPorDia;
	
	/**
	 * Constructor de las ofertas de tipo vacacional que se inicializaran con lso datos princiapales de estas ofertas.
	 * 
	 * @param fechaI, fecha inicio de la oferta.
	 * @param fechaF, fecha final de la oferta.
	 * @param precioDia, precio por d�a.
	 * @param Descripcion, descripcion de la oferta.
	 * @param Fianza, fianza de alquilar la oferta.
	 * @param Reservada, condici�n que dice si la oferta est� reservada o no.
	 * @param Contratada, condici�n que dice si la oferta est� contratada o no.
	 * @param FechaCrea, fecha de creaci�n de la oferta.
	 *
	 */
	public Vacacional(LocalDate fechaI, LocalDate fechaF, int precioDia, int Fianza, Boolean Reservada, Boolean Contratada, LocalDate FechaCrea, UsuarioRegistrado Duenio) {
		super(Fianza, Reservada, Contratada, FechaCrea, Duenio);
		_fechaInicio = fechaI;
		_fechaFin = fechaF;
		_precioPorDia = precioDia;
	}
	
	/**
	 * Obtiene la fecha de inicio de la oferta vacacional.
	 * 
	 * @return fecha inicio.
	 */
	public LocalDate getFechaInicio() {
		return _fechaInicio;
	}
	
	/**
	 * Obtiene la fecha de inicio.
	 * 
	 * @return fecha de inicio.
	 */
	public LocalDate getFechaIni() {
		return _fechaInicio;
	}
	
	/**
	 * Obtiene el tipo de oferta.
	 * 
	 * @return tipo de oferta.
	 */
	public String getTipo() {
		return "vacacional";
	}
	
	/**
	 * Obtiene la fecha fin de la oferta vacacional.
	 * 
	 * @return fecha final.
	 */
	public LocalDate getFechaFin() {
		return _fechaFin;
	}
	
	/**
	 * Obtiene el precio por d�a de una oferta vacacional.
	 * 
	 * @return precio por dia.
	 */
	public int getPrecioPorDia() {
		return _precioPorDia;
	}
	
	/**
	 * Obtiene el precio final por una estancia vacacional.
	 * 
	 * @return precio final.
	 */
	public long precioFinal() {
		long total = 0;
		
		long dif = _fechaInicio.until(_fechaFin, ChronoUnit.DAYS);
		total = dif * _precioPorDia + super.getFianzaOferta();
		return total;
	}
	
}
