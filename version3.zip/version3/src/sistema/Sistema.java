package sistema;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

import es.uam.eps.padsof.telecard.*;


/**
 * Clase principal que representa nuestro sistema.
 * Sirve para manejar el sistema entero as� como para modificar sus campos y datos.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Sistema implements Serializable{
	
	private static final long serialVersionUID = -7749627954515334575L;
	
	private static String _dniGerente = "0000000000";
	private static String _contraseniaGerente = "PADSOF";
	private boolean esGerente;
	private static Sistema _sistema = null; //hacer un public static getSistema que mire si es null y si no lllame al construcot ry devuelva ese nuevoc reado  !!!!! mirar patron singleton
	private UsuarioRegistrado _usuarioActivo; //para que haya un unico usuario y se actualiza al hacer login
	private ArrayList<UsuarioRegistrado> _usuariosSistema = new ArrayList<UsuarioRegistrado>(); //usuarios que estan registrados en el sistema
	private ArrayList<Vivienda> _viviendasSistema = new ArrayList<Vivienda>();
	private ArrayList<Oferta> _ofertasSistema = new ArrayList<Oferta>();
	private ArrayList<Valoracion> _valoracionesSistema = new ArrayList<Valoracion>();
	private ArrayList<Oferta> _ofertasAAceptar = new ArrayList<Oferta>();
	private ArrayList<UsuarioRegistrado> _usuariosBloqueados = new ArrayList<UsuarioRegistrado>();
	//private ArrayList<String> _sugerenciasOfertas = new ArrayList<String>();
		
	/**
	 * Constructor del sistema, existe unicamente para derrotar la instanciaci�n.
	 */
	private Sistema() {
		/* Existe para derrotar la instanciacion */
	}
	
	/**
	 * Limpia el contenido de todos los arrays de datos del sistema.
	 */
	public void limpiarSistema() {
			_usuariosSistema.clear();
			_viviendasSistema.clear();
			_ofertasSistema.clear();
	}
	
	public Boolean esGerente() {
		if(esGerente == true) {
			return true;
		}
		return false;
	}
	
	/**
	 * Devuelve el sistema si est� creado, y en caso de que no haya uno, lo crea y lo devuelve.
	 * 
	 * @return sistema
	 */
	public static Sistema getSistema() {
		if(_sistema == null) {
			_sistema = new Sistema();
			
			File basededatos = new File("sistema.txt");
			if(basededatos.exists()) {
				_sistema = Sistema.leerSistema();
			} else {
				_sistema.leerFicheroUsuarios("usuarios.txt");
			}
		}
		
		return _sistema;
	}
	
	/**
	 * Devuelve el array de los usuarios que est�n bloqueados.
	 * 
	 * @return lista con los usuarios bloqueados.
	 */
	public ArrayList<UsuarioRegistrado> getUsuariosBloqueados() {
		return _usuariosBloqueados;
	}
	/**
	 * A�ade un usuario al array de los usuarios que est�n bloqueados.
	 * 
	 * @return lista con los usuarios bloqueados.
	 */
	public void addUsuariosBloqueado(UsuarioRegistrado u) {
		_usuariosBloqueados.add(u);
	}
	/**
	 * Obtiene el usuario que esta logueado en el sistema.
	 * 
	 * @return usuario 
	 */
	public UsuarioRegistrado getUsuarioLogeado() {
		return _usuarioActivo;
	}
	
	/**
	 * Devuelve el array de ofertas que est�n pendientes de ser aceptadas.
	 * 
	 * @return la lista de las ofertas a aceptar.
	 */
	public ArrayList<Oferta> getOfertasAceptar() {
		return _ofertasAAceptar;
	}
	
	/**
	 * Comprueba que existe el usuario y que la contrase�a es correcta.
	 * 
	 * @param dni, el numero de dni a comprobar
	 * @param contrasenia, la contrase�a a comprobar
	 * 
	 * @return true si el dni y contrase�a corresponden con un usuario del sistema, false si no.
	 */
	public Boolean login(String dni, String contrasenia) {
		
		if(_usuarioActivo != null) {
			System.out.println("Ya hay otro usuario usando la aplicaci�n.");
			return false;
		}
		
		if(esGerente == true) {
			System.out.println("El gerente est� logueado, sorry e intentalo mas tarde.");
			return false;
		}
		
		if(_dniGerente.equals(dni)) {
			if(_contraseniaGerente.equals(contrasenia)) {
				esGerente = true;
				_usuarioActivo = new UsuarioRegistrado("G", "Gerente", "Gerente", "x", "x", "x", 0);
				System.out.println("Registrado como gerente :).");
				return true;
			}
		}
		for(int i=0; i< _usuariosSistema.size(); i++) {			
			if(_usuariosSistema.get(i).getDni().equalsIgnoreCase(dni)) {
				if(_usuariosSistema.get(i).getContrasenia().equals(contrasenia)) {
					_usuarioActivo = _usuariosSistema.get(i);
					if(_usuarioActivo.getPerfilOfertante() instanceof Ofertante & _usuarioActivo.getPerfilDemandante() instanceof Demandante) {
						System.out.println("Entrando al sistema como usuario ofertante y demandante.");
						return true;
					}
					if(_usuarioActivo.getPerfilOfertante() instanceof Ofertante) {
						System.out.println("Entrando al sistema como usuario ofertante.");
						return true;
					}
					if(_usuarioActivo.getPerfilDemandante() instanceof Demandante) {
						System.out.println("Entrando al sistema como usuario demandante.");
						return true;
					}
				}
			}
		}
		System.out.println("Credenciales incorrectas....");
		
		return false;
	}
	
	/**
	 * Pone los campos de usuario y gerente a null si estaban inicializados, en el caso de gerente a false.
	 * 
	 * @return true si se han puesto a null/false, false si no habia nadie logueado.
	 */
	public Boolean logout() {
		if(esGerente == false & _usuarioActivo == null) {
			System.out.println("No hay nadie en el sistema, imposible hacer logout.");
			return false;
		}
		if(esGerente == true ) {
			esGerente = false;
			_usuarioActivo = null;
			System.out.println("Logout de Gerente :(.");
			guardarSistema();
			return true;			
		}
		if(_usuarioActivo != null) {
			_usuarioActivo = null;
			System.out.println("Logout de usuario.");
			guardarSistema();
			return true;
		}
		guardarSistema();
		return false;
	}
	
	/**
	 * Devuelve los usuarios que est�n registrados en el sistema
	 * 
	 * @return array de usuarios registrados del sistema..
	 */
	public ArrayList<UsuarioRegistrado> getUsuariosSistema() {
		return _usuariosSistema;
	}
	
	
	/**
	 * A�ade una vivienda al usuario que est� registrado ahora mismo en el sistema y a la lista de viviendas del sistema.
	 * 
	 * @param v1, vivienda a a�adir
	 * 
	 * @return true si se ha a�adido correctamente, false si no.
	 */	
	public Boolean a�adirVivienda(Vivienda v1) {
		UsuarioRegistrado u = _sistema.getUsuarioLogeado();
		if(u.tienePerfilOfertante()) {
			((Ofertante)u.getPerfilOfertante()).a�adirVivienda(v1);
			_viviendasSistema.add(v1);
			System.out.println("Vivienda a�adida con �xito.");
			return true;
		}
		return false;
	}
	
	/**
	 * A�ade una valoraci�n a una oferta.
	 * 
	 * @param o1, oferta sobre la que se realiza la valoraci�n.
	 * @param v1, valoraci�n sobre la oferta o1.
	 */
	public void a�adirValoracion(Oferta o1, Valoracion v1) {
		if(_usuarioActivo != null) {
			for(int i=0; i<_ofertasSistema.size();i++) {
				if(_ofertasSistema.get(i).equals(o1)) {
					System.out.println("Encontrada oferta, a�adiendo valoraci�n");
					_ofertasSistema.get(i).valorarOferta(v1);
					_valoracionesSistema.add(v1);
				}
			}
		}
	}
	
	
	public ArrayList<Comentario> getComentarios(Oferta o1) {
		ArrayList<Comentario> coments = new ArrayList<Comentario>();
		for(int i=0; i<_ofertasSistema.size();i++) {
			if(_ofertasSistema.get(i).equals(o1)) {
				for(int j=0; j<_ofertasSistema.get(i).getValoracionesOferta().size();j++) {
					if(_ofertasSistema.get(i).getValoracionesOferta().get(j) instanceof Comentario) {
						coments.add((Comentario)_ofertasSistema.get(i).getValoracionesOferta().get(j));
					}

				}
			}
		}
		return coments;
	}
	
	/**
	 * Obtiene una valoracion en concreto.
	 * 
	 * @param v1, valoracion a obtener.
	 * 
	 * @return valoracion obtenida, o null si no existe.
	 */
	public Valoracion getValoracion(Valoracion v1) {
		for(int i=0;i<_valoracionesSistema.size();i++) {
			if(v1 instanceof ValoracionNumerica) {
				if(((ValoracionNumerica)_valoracionesSistema.get(i)).equals(v1)) {
					return (ValoracionNumerica)_valoracionesSistema.get(i);
				}
			}
			if(v1 instanceof Comentario) {
				if(((Comentario)_valoracionesSistema.get(i)).equals(v1)) {
					return (Comentario)_valoracionesSistema.get(i);
				}
			}
		}
		System.out.println("No se ha encontrado la valoracion deseada.");
		return null;
	}
	
	/**
	 * Obtiene la lista de valoraciones que tiene el sistema.
	 * 
	 * @return array con las valoraciones del sistema.
	 */
	public ArrayList<Valoracion> getValoracionesSistema() {
		return _valoracionesSistema;
	}
	
	public ArrayList<Comentario> getComentarios() {
		ArrayList<Comentario> c = new ArrayList<Comentario>();
		
		for(int i=0;i<_valoracionesSistema.size();i++) {
			if(_valoracionesSistema.get(i) instanceof Comentario) {
				c.add((Comentario) _valoracionesSistema.get(i));
			}
		}
		return c;
	}
		
	/**
	 * Obtiene la valoraci�n media de una oferta.
	 * 
	 * @param o1, oferta sobre la que se quiere saber la media de su valoraci�n.
	 * 
	 * @return la media de todas las valoraciones.
	 */
	public double getValoracionMediaOferta(Oferta o1) {
		double total = 0;
		double aux = 0;
		int i, j=1;
		for(i=0; i<_ofertasSistema.size(); i++) {
			if(_ofertasSistema.get(i).equals(o1)) {
				for(j = 0; j<_ofertasSistema.get(i).getValoracionesOferta().size(); j++) {
					if(_ofertasSistema.get(i).getValoracionesOferta().get(j) instanceof ValoracionNumerica) {
						 aux = ((ValoracionNumerica) _ofertasSistema.get(i).getValoracionesOferta().get(j)).getValorNumerico();	
						 total = total + aux;
					}
				}				
			}
		}
		
		total = total/(j);
		return total;
	}
	
	/**
	 * Obtiene todas las viviendas que est�n registradas en el sistema.
	 * 
	 * @return array con las viviendas registradas en el sistema.
	 */
	public ArrayList<Vivienda> getViviendasSistema() {
		return _viviendasSistema;
	}
	
	/**
	 * Obtiene una vivienda en concreto de todo el sistema.
	 * 
	 * @param v1, vivienda que se va a buscar en el sistema.
	 * 
	 * @return la vivienda se devuelve de la memoria del sistema si se ha encontrado.
	 */
	public Vivienda getVivienda(Vivienda v1) {
		for(int i = 0; i<_viviendasSistema.size(); i++) {
			if(_viviendasSistema.get(i).equals(v1)) {
				return _viviendasSistema.get(i);
			}
		}
		
		return null;
	}
	
	/**
	 * Obtiene las todas las ofertas que han sido registradas en el sistema.
	 * 
	 * @return array con todas las ofertas del sistema.
	 */
	public ArrayList<Oferta> getOfertasSistema() {
		return _ofertasSistema;
	}
	
	/**
	 * Obtiene una oferta concreta del sistema
	 * 
	 * @param o1, la oferta que se busca en el sistema.
	 * 
	 * @return la oferta se devuelve de la memoria del sistema si se ha encontrado.
	 */
	public Oferta getOferta(Oferta o1) {
		for(int i = 0; i<_ofertasSistema.size(); i++) {
			if(_ofertasSistema.get(i).equals(o1)) {
				return _ofertasSistema.get(i);
			}
		}
		
		return null;
	}
	
	/**
	 * Lee un fichero de usuarios y genera los usuarios registrados que contiene el fichero.
	 *  
	 *  @param fichero, el nombre del fichero de donde se van a leer los usuarios.
	 *  
	 *  @return true si se ha leido con exito, false si no.
	 */
	public Boolean leerFicheroUsuarios(String fichero){

		System.out.println("Leyendo fichero de usuarios...");
		
		try {
			FileInputStream stream;
			stream = new FileInputStream(fichero);
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader buffer = new BufferedReader(reader);
			String linea;
			linea = buffer.readLine();
	 
			while (linea!=null) {
				 StringTokenizer palabra = new StringTokenizer(linea, ";");
				 
				 String LRoll;
				 String LDNI; 
				 String LContrase�a;      
				 String LNombre;
				 String LApellidos;
				 String LTarjeta;
				 String var;

				 while (palabra.hasMoreTokens()) {
					 
					 LRoll = palabra.nextToken();
					 LDNI = palabra.nextToken();
					 var = palabra.nextToken();
					 StringTokenizer aux = new StringTokenizer(var, ",");
					 LApellidos = aux.nextToken();
					 LNombre = aux.nextToken();
					 LContrase�a = palabra.nextToken();
					 LTarjeta = palabra.nextToken();
					 
					 UsuarioRegistrado ur1 = new UsuarioRegistrado(LRoll, LNombre, LApellidos, LTarjeta, LDNI, LContrase�a, 0);
					 _usuariosSistema.add(ur1);

			     }
				 linea = buffer.readLine();
			 }
			 stream.close();
			 
			 System.out.println("Fichero leido correctamente");
			 
			 return true;
		} catch (FileNotFoundException e) {
			System.out.println("Error, no se ha encontrado el archivo :(.");
			return false;
		} catch (IOException e) {
			System.out.println("Error input/output :(.");
			return false;
		}		
	}
	
	/**
	 * Compra directamente una oferta
	 * 
	 * @param o1, oferta a comprar.
	 * @param demandante, usuarioRegistrado que quiere comprar.
	 * @param ofertante, usuarioRegistrado propietario de la vivienda.
	 * @param concepto, concepto de la transacci�n.
	 * 
	 * @return true si se ha comprado correctamente, false si ya esta comprada o reservada, o ha habido un fallo.
	 */
	public Boolean compraDirectaOferta(Oferta o1, UsuarioRegistrado demandante, UsuarioRegistrado ofertante, String concepto) {
		
		int i = 0;
		if(o1.getReservaOferta() != null) {
			System.out.println("Ya existe una reserva, por lo que no se puede comprar directamente esta oferta.");
			return false;
		}
		
		if(o1.getContratadaOferta() == true) {
			System.out.println("Oferta contratada previamente.");
			return false;
		}
		if(_usuarioActivo == null) {
			System.out.println("No hay ning�n usuario registrado...");
			return false;
		}
		
		if(demandante.getPerfilDemandante().getTipoUsuario().equalsIgnoreCase("Demandante")) {
			for(i = 0; i< _ofertasSistema.size();i++) {
				if(_ofertasSistema.get(i).equals(o1)) {
					System.out.println("Oferta encontrada, procediendo al pago...");
			
					if(_ofertasSistema.get(i) instanceof Vacacional) {
						double aux = ((Vacacional) _ofertasSistema.get(i)).precioFinal();
						try {				
							TeleChargeAndPaySystem.charge(demandante.getTarjetaCredito(), concepto, aux);
							System.out.println("Cobro al demandante realizado correctamente.");
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito demandante :(.");
							demandante.setUsuarioBloqueado();
							_usuariosBloqueados.add(demandante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					if(_ofertasSistema.get(i) instanceof Vacacional) {
						double aux = ((Vacacional) _ofertasSistema.get(i)).precioFinal();
						try {				
							aux = aux * (2/100);
							TeleChargeAndPaySystem.charge(ofertante.getTarjetaCredito(), "Pago por alquiler mensual ", -(aux));
							System.out.println("Pago al ofertante realizado correctamente. (vacacional)");
							_ofertasSistema.get(i).setComprador(demandante);
							_ofertasSistema.get(i).setContratada();
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito ofertante :(.");
							ofertante.setUsuarioBloqueado();
							_usuariosBloqueados.add(ofertante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						double aaux = ((AlquilerMensual)_ofertasSistema.get(i)).precioFinal();
						try {
							TeleChargeAndPaySystem.charge(demandante.getTarjetaCredito(), concepto, aaux);
							System.out.println("Cobro al demandante realizado correctamente2.");
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito demandante :(.");
							demandante.setUsuarioBloqueado();
							_usuariosBloqueados.add(demandante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						double aaux = ((AlquilerMensual)_ofertasSistema.get(i)).precioFinal();
						try {
							aaux = aaux * (0.1/100);
							TeleChargeAndPaySystem.charge(ofertante.getTarjetaCredito(), "Pago por alquiler mensual ", -(aaux));
							System.out.println("Pago al ofertante realizado correctamente. (alquiler mensual)");
							(((Demandante)demandante.getPerfilDemandante())).a�adirOfertaContratada(_ofertasSistema.get(i));
							_ofertasSistema.get(i).setComprador(demandante);
							_ofertasSistema.get(i).setContratada();
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito ofertante:(.");
							ofertante.setUsuarioBloqueado();
							_usuariosBloqueados.add(demandante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					return true;
				}
			}
		}
		return false;
	}
		
	/**
	 * Devuelve el array de viviendas de un usuario registrado Ofertante.
	 * 
	 * @param ur1, usuario registrado.
	 * 
	 * @return lista de viviendas del ofertante.
	 */
	public ArrayList<Vivienda> getViviendasOfertante(UsuarioRegistrado ur1) {
		if(ur1.getPerfilOfertante().getTipoUsuario().equalsIgnoreCase("Ofertante")) {
			return (((Ofertante)ur1.getPerfilOfertante())).getViviendas();
		}
		return null;
	}
	
	/**
	 * Acepta una oferta si el usuario logeado actual es el gerente.
	 * 
	 * @param o1, oferta a aceptar.
	 * 
	 * @return true si se ha a�adido correctamente, false si no.
	 */
	public Boolean aceptarOferta(Oferta o1) {
		if(esGerente == true) {
			for(int i=0;i<_ofertasAAceptar.size();i++) {
				if(_ofertasAAceptar.get(i).equals(o1)) {
					_ofertasSistema.add(o1);
					_ofertasAAceptar.remove(i);
					System.out.println("�xito al a�adir la oferta :D" );
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * Rechaza una oferta por parte del gerente.
	 * 
	 * @param o1, oferta a rechazar.
	 * 
	 * @return true si se ha rechazado y borrado la oferta, false si no.
	 */
	public Boolean rechazarOferta(Oferta o1) {
		if(esGerente == true) {
			_ofertasAAceptar.remove(o1);
			o1 = null;
			return true;
		}
		
		return false;
	}
	
	/**
	 * Sugiere cambios a un ofertante sobre una de sus ofertas.
	 * 
	 * @param cambios, cambios a realizar.
	 * @param v1, vivienda sobre la que se ha realizado la oferta.
	 * @param o1, oferta sobre la que se van a realizar los cambios.
	 * @param ur1, el usuario propietario de la oferta y la vivienda.
	 * 
	 * @return true si se ha mandado el mensaje al usuario, false si no.
	 */
	public Boolean sugerirCambiosOferta(String cambios, Vivienda v1, Oferta o1, UsuarioRegistrado ur1) {

		if(esGerente == true) {
			if(v1.getOfertaConcreta(o1) != null) {
				if(ur1.getPerfilOfertante() instanceof Ofertante) {
					_ofertasAAceptar.remove(o1);
					((Ofertante)ur1.getPerfilOfertante()).a�adirSugerencia(cambios);
					return true;
				}
			}
		}
		
		return false;
	}
	
	public void anularReserva(UsuarioRegistrado u1, Oferta o1) {
		if(_usuarioActivo != null) {
			for(int i=0; i<_ofertasSistema.size();i++) {
				if(_ofertasSistema.get(i).equals(o1)) {
					System.out.println("Anulando reserva");
					for(int j=0;j<((Demandante)_usuarioActivo.getPerfilDemandante()).getOfertasReservadas().size();j++) {
						if(((Demandante)_usuarioActivo.getPerfilDemandante()).getOfertasReservadas().get(j).equals(o1)) {
							((Demandante)_usuarioActivo.getPerfilDemandante()).getOfertasReservadas().get(j).anularReserva();
						}
					}
					_ofertasSistema.get(i).anularReserva();
					return;
				}
			}
		}
	}
	
	/**
	 * Mete en el sistema una oferta que tiene que ser aceptada por el gerente.
	 * 
	 * @param o1 que se va a meter en el sistema.
	 */
	public void crearOferta(Oferta o1, Vivienda v1) {
		if(_usuarioActivo.tienePerfilOfertante() == true) {
			_ofertasAAceptar.add(o1);
			for(int i=0;i<_viviendasSistema.size();i++) {
				if(_viviendasSistema.get(i).equals(v1)) {
					_viviendasSistema.get(i).a�adirOferta(o1);
					System.out.println("Ofert creada con exito.");
					break;
				}
			}
		}
	}
	
	/**
	 * Reserva la oferta.
	 * 
	 * @param o1, la oferta que se va a reservar.
	 * @param r1, la reserva que se va a realizar.
	 * @param ur1, el usuario que realiza la reserva.
	 * 
	 * @return true si la reserva se ha efectuado correctamente, false si ya se ha reservado, o si est� contratada
	 */
	public Boolean reservarOferta(Oferta o1, Reserva r1) {
		if(o1.getReservadaOferta() == true) {
			System.out.println("Oferta previamente reservada.");
			return false;
		}
		
		if(o1.getContratadaOferta() == true) {
			System.out.println("La oferta ya ha sido contratada por otra persona.");
			return false;
		}
		
		if(_usuarioActivo != null) {
			if(_usuarioActivo.tienePerfilDemandante()) {
				for(int i=0; i<_ofertasSistema.size();i++) {
					if(_ofertasSistema.get(i).equals(o1)) {
						System.out.println("Oferta encontrada, procediendo a reservar...");
						_ofertasSistema.get(i).setComprador(r1.getUsuarioReserva());
						_ofertasSistema.get(i).setReserva(r1);
						_ofertasSistema.get(i).setReservada();

						System.out.println(_usuariosSistema.indexOf(_usuarioActivo));	
						
						((Demandante)_usuariosSistema.get(_usuariosSistema.indexOf(_usuarioActivo)).getPerfilDemandante()).a�adirOfertaContratada(o1);
						((Demandante)_usuarioActivo.getPerfilDemandante()).a�adirOfertaReservada(o1);

						System.out.println("Oferta reservada con �xito :D.");
						return true;
					}
				}		
				System.out.println("No se ha encontrado la oferta en el sistema.");
			}
		} else {
			System.out.println("No hay usuario activo");
		}
		return false;
	}
	
	/**
	 * Paga una reserva que se ha hecho previamente, llamando al metodo TeleChargeAndPaySystem.
	 * 
	 * @param demandante, comprador de la oferta.
	 * @param ofertante, propietario de la oferta.
	 * @param o1, oferta.
	 * @param concepto, concepto de la transferencia bancaria.
	 * 
	 * @return true si se han ejecutando correctamente ambas transferencias, false si no.
	 */
	public Boolean pagarReserva(UsuarioRegistrado demandante, UsuarioRegistrado ofertante, Oferta o1, String concepto) {
		int i = 0;
		int j = 0;
		int z = 0;
		LocalDate hoy = LocalDate.now();
		int dia=0;	
		
		for(int x=0; x<_ofertasSistema.size();x++) {
			if(_ofertasSistema.get(x).equals(o1)) {
				System.out.println("Oferta encontrada, procediendo al pago...");
			}
		}
		
		if(o1 instanceof Vacacional) {
			dia = ((Vacacional) o1).getReservaOferta().getFechaIniReserva().getDayOfYear();
			if((hoy.getDayOfYear()-dia) > 5) {
				System.out.println("Fecha l�mite de la reserva excedida.");
				return false;
			}
		}
		
		if(o1 instanceof AlquilerMensual) {
			dia = ((AlquilerMensual) o1).getReservaOferta().getFechaIniReserva().getDayOfYear();
			if((hoy.getDayOfYear()-dia) > 5) {
				System.out.println("Fecha l�mite de la reserva excedida.");
				return false;
			}
		}
		
		if(_usuarioActivo == null) {
			System.out.println("No hay ning�n usuario registrado...");
			return false;
		}
		
		for(z=0;z<_ofertasSistema.size();z++) {
			if(_ofertasSistema.get(z).equals(o1)) {
				if(_ofertasSistema.get(z).getContratadaOferta()) {
					System.out.println("Oferta ya contratada :(");
					return false;
				}
				if(_ofertasSistema.get(z).getReservadaOferta() == false) {
					System.out.println("Aun no has reservado esta oferta.");
					return false;
				}
			}
		}

		if(demandante.getPerfilDemandante().getTipoUsuario().equalsIgnoreCase("Demandante")) {
			for(i=0; i<_ofertasSistema.size(); i++) {
				if(_ofertasSistema.get(i).equals(o1)) {
					if(_ofertasSistema.get(i) instanceof Vacacional) {
						double aux = ((Vacacional)_ofertasSistema.get(i)).precioFinal();
						try {
							TeleChargeAndPaySystem.charge(demandante.getTarjetaCredito(), concepto, aux);
							System.out.println("Cobro al demandante realizado correctamente.");
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito demandante :(.");
							demandante.setUsuarioBloqueado();
							_usuariosBloqueados.add(demandante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					if(_ofertasSistema.get(i) instanceof Vacacional) {
						double aux = ((Vacacional)_ofertasSistema.get(i)).precioFinal();
						try {
							aux = aux * (2/100);							
							TeleChargeAndPaySystem.charge(ofertante.getTarjetaCredito(), "Pago por alquiler mensual de su oferta: " , -(aux));
							System.out.println("Pago al ofertante efectuado. (vacacional)");
							_ofertasSistema.get(i).setComprador(demandante);
							_ofertasSistema.get(i).setContratada();
							for(j = 0; j<_usuariosSistema.size();j++) {
								if(_usuariosSistema.get(j).equals(demandante)) {
									((Demandante)_usuariosSistema.get(j).getPerfilDemandante()).a�adirOfertaContratada(o1);
								}
							}
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito ofertante :(.");
							ofertante.setUsuarioBloqueado();
							_usuariosBloqueados.add(ofertante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						double aaux =  ((AlquilerMensual)_ofertasSistema.get(i)).precioFinal();
						try {
							TeleChargeAndPaySystem.charge(demandante.getTarjetaCredito(), concepto, aaux);
							System.out.println("Cobro al demandante realizado correctamente.");
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito demandante :(.");
							demandante.setUsuarioBloqueado();
							_usuariosBloqueados.add(demandante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}					
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						double aaux =  ((AlquilerMensual)_ofertasSistema.get(i)).precioFinal();
						try {
							aaux = aaux * (0.1/100);
							TeleChargeAndPaySystem.charge(ofertante.getTarjetaCredito(), "Pago por alquiler mensual de su oferta: " , -(aaux));
							System.out.println("Pago al ofertante efectuado. (alquiler mensual)");
							_ofertasSistema.get(i).setComprador(demandante);
							_ofertasSistema.get(i).setContratada();
							for(j = 0; j<_usuariosSistema.size();j++) {
								if(_usuariosSistema.get(j).equals(demandante)) {
									((Demandante)_usuariosSistema.get(j).getPerfilDemandante()).a�adirOfertaContratada(o1);
								}
							}
						} catch (InvalidCardNumberException e) {
							System.out.println("Error en la tarjeta de cr�dito ofertante :(.");
							ofertante.setUsuarioBloqueado();
							_usuariosBloqueados.add(ofertante);
							return false;
						} catch (FailedInternetConnectionException e) {
							System.out.println("Error con la conexi�n :(.");
							return false;
						} catch (OrderRejectedException e) {
							System.out.println("Operaci�n rechazada :(.");
							return false;
						}
					}
					System.out.println("La reserva de la vivienda ha sido pagada correctamente. Dinero subtra�do del demandante e ingresado al ofertante.");
					return true;
				}
			}	
		}		
		return false;
	}
	
	
	/**
	 * Busca las ofertas sobre viviendas de un c�digo postal determinado, y devuelve un array con ellas.
	 * 
	 * @param cp, codigo postal de la vivienda.
	 * 
	 * @return array con los resultados de la b�squeda..
	 */
	public ArrayList<Oferta> busquedaCP(int cp) {
		ArrayList<Oferta> resultados = new ArrayList<Oferta>();
		for(int i = 0; i< _viviendasSistema.size(); i++) {
			if(_viviendasSistema.get(i).getCodigoPostal() == (cp)) {
				System.out.println("Encontrada:" + _viviendasSistema.get(i).getDescripcionVivienda());
				for(int j = 0; j <_viviendasSistema.get(i).getOfertasVivienda().size(); j++) {
					for(int z = 0; z<_ofertasSistema.size();z++) {
						if(_viviendasSistema.get(i).getOfertasVivienda().get(j).equals(_ofertasSistema.get(z))) {
							resultados.add(_viviendasSistema.get(i).getOfertasVivienda().get(j));
						}
					}
				}
			}
		}		
		return resultados;
	}
		
	/**
	 * Busca las ofertas sobre viviendas desde una fecha inicial, y devuelve un array con ellas.
	 * 
	 * @param fechaIni, fecha de inicio de las b�squedas.
	 * @param fechaFin, fecha de finalizaci�n de las b�squedas.
	 * 
	 * @return array con los resultados de la b�squeda.
	 */
	public ArrayList<Oferta> busquedaFechas(String anio, String mes, String dia) {
		ArrayList<Oferta> resultados = new ArrayList<Oferta>();
				
		int diaa, mess, anioo;		
		diaa= Integer.parseInt(dia);
		mess = Integer.parseInt(mes);
		anioo = Integer.parseInt(anio);
		
		if(diaa < 1 || diaa > 31 || mess < 1 || mess > 12 || anioo < 2018) {
			System.out.println("Fecha introducida incorrecta");
			return null;
		}
		
		
		for(int i=0; i<_ofertasSistema.size();i++) {
			Oferta o1 = _ofertasSistema.get(i);
			if(o1 instanceof Vacacional) {
				Vacacional v1 = (Vacacional)o1;
				if(v1.getFechaIni().getDayOfMonth() <= diaa && v1.getFechaIni().getMonthValue() <= mess &&
						v1.getFechaIni().getYear() <= anioo) {
					resultados.add(v1);
				}
			if(o1 instanceof AlquilerMensual) {
				AlquilerMensual am1 = (AlquilerMensual)o1;
				if(am1.getFechaIni().getDayOfMonth() <= diaa && am1.getFechaIni().getMonthValue() <= mess &&
						am1.getFechaIni().getYear() <= anioo) {
					resultados.add(am1);
				}
			}
			}
		}
				
		return resultados;
	}

	/**
	 * Busca las ofertas sobre el tipo de ofertas de las viviendas, y devuelve un array con ellas.
	 * 
	 * @param tipo, tipo de oferta
	 * 
	 * @return array con los resultados de la b�squeda.
	 */
	public ArrayList<Oferta> busquedaTipoOferta(String tipo) {
		ArrayList<Oferta> v = new ArrayList<Oferta>();
		ArrayList<Oferta> am = new ArrayList<Oferta>();
		
		for(int i = 0; i<_ofertasSistema.size(); i++) {
			if(_ofertasSistema.get(i) instanceof Vacacional) {
				if(((Vacacional)_ofertasSistema.get(i)).getTipo().equalsIgnoreCase("vacacional"))
					v.add(_ofertasSistema.get(i));
			}
			if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
				if(((AlquilerMensual)_ofertasSistema.get(i)).getTipo().equalsIgnoreCase("alquilermensual"))
					am.add(_ofertasSistema.get(i));
				}
		}
			
		if(tipo.equalsIgnoreCase("vacacional")) {
			return v;
		}
		if(tipo.equalsIgnoreCase("mensual") || tipo.equalsIgnoreCase("alquilermensual") || tipo.equalsIgnoreCase("alquiler mensual")) {
			return am;
		}
		
		return null;
				
	}
	/**
	 * Cambia el numero de la tarjeta de un usuario Registrado.
	 *  
	 * @param ur1, usuario registrado a cambiar la tarjeta.
	 * @param tCredito, nuevo numero de la tarjeta.
	 *  
	 * @return true si se ha cambiado con exito, false si no.
	 */	
	public Boolean cambiarTarjeta(UsuarioRegistrado ur1, String tCredito) {
		for(int i=0;i<_usuariosBloqueados.size();i++) {
			if(_usuariosBloqueados.get(i).equals(ur1)) {
				if(_usuariosBloqueados.get(i).getBloqueado() == true) {
					
					_usuariosBloqueados.get(i).setUsuarioNoBloqueado();
					_usuariosBloqueados.get(i).setTarjetaCredito(tCredito);
					_usuariosBloqueados.remove(i);
					return true;
				}
			}
		}
		
		return false;
	}
	/**
	 * Anula una oferta pasada como par�metro si pertenece al sistema.
	 * 
	 * @param o1, oferta a borrar.
	 *  
	 * @return true si se ha borrado correctamente, false si no.
	 */	
	public Boolean anularOferta(Oferta o1) {
		for(int i=0; i<_ofertasSistema.size();i++) {
			if(_ofertasSistema.get(i).equals(o1)) {
				_ofertasSistema.remove(i);
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Busca las ofertas que han reservado una vivienda, y devuelve un array con ellas.
	 *  
	 * @return array con los resultados de la b�squeda.
	 */	
	public ArrayList<Oferta> busquedaReservadas() {
		ArrayList<Oferta> resultados = new ArrayList<Oferta>();
		if(_usuarioActivo != null) {
			for(int i = 0; i< _ofertasSistema.size(); i++) {
				if(_ofertasSistema.get(i).getReservadaOferta() == true) {
					if(_ofertasSistema.get(i) instanceof Vacacional) {
							resultados.add(_ofertasSistema.get(i));
					}	
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						if(_ofertasSistema.get(i).getReservadaOferta() == true) {
							resultados.add(_ofertasSistema.get(i));
						}
					}
				}			
			}		
		}
		return resultados;
	}
	
	/**
	 * Devuelve un array con las ofertas que ya han sido contratadas/pagadas.
	 * 
	 * @return array con las ofertas pagadas.
	 */
	public ArrayList<Oferta> busquedaPagadas() {
		ArrayList<Oferta> resultados = new ArrayList<Oferta>();
		if(_usuarioActivo != null) {
			for(int i = 0; i< _ofertasSistema.size(); i++) {
				if(_ofertasSistema.get(i).getContratadaOferta() == true) {
					if(_ofertasSistema.get(i) instanceof Vacacional) {
							resultados.add(_ofertasSistema.get(i));
					}	
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						if(_ofertasSistema.get(i).getContratadaOferta() == true) {
							resultados.add(_ofertasSistema.get(i));
						}
					}
				}			
			}		
		}
		return resultados;
	}
	/**
	 * Busca las ofertas que han contratado una vivienda, y devuelve un array con ellas.
	 *  
	 * @return array con los resultados de la b�squeda.
	 */	
	public ArrayList<Oferta> busquedaContratadas() {
		ArrayList<Oferta> resultados = new ArrayList<Oferta>();
		if(_usuarioActivo != null) {
			for(int i = 0; i< _ofertasSistema.size(); i++) {
				if(_ofertasSistema.get(i).getContratadaOferta() == true) {
					if(_ofertasSistema.get(i) instanceof Vacacional) {
							resultados.add(_ofertasSistema.get(i));
					}	
					if(_ofertasSistema.get(i) instanceof AlquilerMensual) {
						if(_ofertasSistema.get(i).getContratadaOferta() == true) {
							resultados.add(_ofertasSistema.get(i));
						}
					}
				}			
			}		
		}
		return resultados;
	}
	
	/**
	 * Busca las ofertas por la valoraci�n de una oferta, y devuelve un array con ellas.
	 * 
	 * @param valor, puntuaci�n que se le da.
	 *  
	 * @return array con los resultados de la b�squeda.
	 */	
	public ArrayList<Oferta> busquedaValoracion(double valor) {
		ArrayList<Oferta> resultados = new ArrayList<Oferta>();
		if(_usuarioActivo != null) {
			for(int i=0; i<_ofertasSistema.size();i++) {
				if(getValoracionMediaOferta(_ofertasSistema.get(i)) >= valor) {
					resultados.add(_ofertasSistema.get(i));
				}
			}					
		}		
		return resultados;
	}
		
	/**
	 * Guarda el sistema actual en un fichero de datos, en este caso sistema.txt.
	 * 
	 * @return true si se ha guardado correctamente, false si ha habido alguna excepci�n.
	 */
	public Boolean guardarSistema()  {
		try {
			ObjectOutputStream nombre = new ObjectOutputStream(new FileOutputStream("sistema.txt"));
			nombre.writeObject(this);
			nombre.close();
	
			return true;
		} catch (FileNotFoundException e) {
			System.out.println("Error, no se ha encontrado el archivo :(.\n");
		} catch (IOException e) {
			System.out.println("Error input/output :(.\n");
		} 
		return false;
	}
	
	/**
	 * Lee un sistema de un fichero de datos, en este caso sistema.txt.
	 * 
	 * @return el sistema le�do.
	 */
	public static Sistema leerSistema(){
		try{
			Sistema s1 = null;
			ObjectInputStream nombre = new ObjectInputStream(new FileInputStream("sistema.txt"));
			s1 = (Sistema) nombre.readObject();
			nombre.close();
			System.out.println("Sistema le�do sin problemas :).");
			return s1;
		} catch (FileNotFoundException e) {
			System.out.println("Error, no se ha encontrado el archivo del sistema :(.\n");
		} catch (IOException e) {
			System.out.println("Error input/output :(.\n");
		} catch(ClassNotFoundException e) {
			System.out.println("Error al encontrar la clase :(.\n");
		}
		
		return null;
	}
} 
	
	

