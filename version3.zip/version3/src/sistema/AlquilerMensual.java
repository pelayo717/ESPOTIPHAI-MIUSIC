package sistema;

import java.time.LocalDate;

/**
 * Clase para manejar los alquileres mensuales de las ofertas.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class AlquilerMensual extends Oferta{
	
	private static final long serialVersionUID = -5712241753067211385L;
	
	private LocalDate _fechaInicio;
	private int _numMeses;
	private int _precioMes;
	
	/**
	 * Constructor del alquiler mensual, que har� referencia a un tipo de oferta.
	 * 
	 * @param fechaI, fecha de inicio de la oferta de alquiler.
	 * @param nMeses, numero de meses que estar� la oferta disponible.
	 * @param precioMes, precio mensual de la oferta.
	 * @param Descripcion, descripcion de la oferta de alquiler mensual.
	 * @param Fianza, fianza del alquiler mensual.
	 * @param Reservada, condici�n que indica si ha sido reservada o no.
	 * @param Contratada, condici�n que indica si ha sido contratada o no.
	 * @param FechaCrea, fecha de creaci�n de la oferta de tipo alquiler mensual.
	 */
	public AlquilerMensual(LocalDate fechaI, int nMeses, int precioMes, int Fianza, Boolean Reservada, Boolean Contratada, LocalDate FechaCrea, UsuarioRegistrado Duenio) {
		super(Fianza, Reservada, Contratada, FechaCrea, Duenio);
		_fechaInicio = fechaI;
		_numMeses = nMeses;
		_precioMes = precioMes;
	}
	
	/**
	 * Obtiene la fecha de inicio del alquiler mensual.
	 * 
	 * @return fecha de inicio de la oferta.
	 */	
	public LocalDate getFechaInicio() {
		return _fechaInicio;
	}
	
	/**
	 * Obtiene el tipo de alquiler
	 * 
	 * @return tipo de alquiler
	 */	
	public String getTipo() {
		return "alquilermensual";
	}
	
	/**
	 * Obtiene la fecha de inicio del alquiler mensual.
	 * 
	 * @return fecha de inicio de la oferta.
	 */	
	public LocalDate getFechaIni() {
		return _fechaInicio;
	}
	
	/**
	 * Obtiene la fecha fin del alquiler mensual.
	 * 
	 * @return fecha fin de la oferta.
	 */	
	public int getFechaFin() {
		return _numMeses;
	}
	
	/**
	 * Obtiene el precio mensual del alquiler mensual.
	 * 
	 * @return precio mensual.
	 */	
	public int getPrecioMes() {
		return _precioMes;
	}
	
	 /**
	 * Obtiene el precio final del alquiler mensual.
	 * 
	 * @return precio total.
	 */	
	public long precioFinal() {
		
		long total = _precioMes + super.getFianzaOferta();
		
		return total;
	}
	
}
