package sistema;

import java.io.Serializable;

/**
 * Clase abstracta para manejar los perfiles de Ofertante y Demandante.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public abstract class Perfil implements Serializable{

	private static final long serialVersionUID = 5783517102778037158L;
	
	private String _tipoUsuario;	

	/**
	 * Constructor de los perfiles, que tendr�n un string con el tipo de usuario que son.
	 * 
	 * @param tipo_, nombre de tipo de usuario
	 */
	public Perfil(String tipo_) {
		_tipoUsuario = tipo_;
	}
	
	/**
	 * Convierte a un string los datos del perfil.
	 * 
	 * @return datos del perfil convertidos a un string.
	 */
	public String toString() {
		String o = "";
		 
		o = o + _tipoUsuario;
		
		return o;
	}
	
	/**
	 * Obtiene un string con el nombre del tipo de usuario.
	 * 
	 * @return nombre del tipo de usuario.
	 */	
	public String getTipoUsuario() {
		return _tipoUsuario;
	}

}
