package sistema;

import java.util.ArrayList;

/**
 * Clase para manejar los comentarios y las respuestas de los mismos.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Comentario extends Valoracion{
	
	private static final long serialVersionUID = 7890922162590160325L;
	
	private String _texto;
	ArrayList<Valoracion> _respuestasComentario = new ArrayList<Valoracion>();
	
	/**
	 * Constructor del comentario, crea un comentario con un texto en su interior.
	 * 
	 * @param texto_, texto del comentario.
	 * @param usuario_, usuario que hace el comentario.
	 */
	public Comentario(String texto_, UsuarioRegistrado usuario_) {
		_texto = texto_;
		super.setUsuarioValoracion(usuario_);
	}
	
	/**
	 * Responde al comentario, creando un nuevo comentario y a�adiendolo al arraylist de respuestas de comentarios.
	 * 
	 * @param v1, respuesta al comentario.
	 */	
	public void a�adirValoracion(Valoracion v1) {
		_respuestasComentario.add(v1);
	}

	/**
	 * Obtiene el texto de un comentario.
	 * 
	 * @return texto del comentario.
	 */
	public String getComentario() {
		return _texto;
	}
	
	/**
	 * Obtiene la valoracion si pertenece al array de respuestas de un comentario.
	 * 
	 * @param v1, valoraci�n a buscar.
	 * 
	 * @return valoraci�n si se ha encontrado, null si no.
	 */
	public Valoracion getValoracion(Valoracion v1) {
		for(int i=0; i<_respuestasComentario.size(); i++) {
			if(_respuestasComentario.get(i).equals(v1)) {
				return _respuestasComentario.get(i);
			}
		}
		return null;
	}
	
	/**
	 * Obtiene las valoraciones/respuestas de un comentario.
	 * 
	 * @return array con las respuestas/valoraciones de un comentario.
	 */
	public ArrayList<Valoracion> getValoraciones() {
		return _respuestasComentario;
	}
	
}
