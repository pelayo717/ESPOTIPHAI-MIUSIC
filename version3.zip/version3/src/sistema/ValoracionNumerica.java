package sistema;

/**
 * Clase que maneja las valoraciones num�ricas de las ofertas del sistema de viviendas.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 */
public class ValoracionNumerica extends Valoracion{
	
	private static final long serialVersionUID = -2474879184149498281L;
	
	private double _numero;
	
	/**
	 * Constructor de la clase Valoracion num�rica, que lo inicializa a un n�mero.
	 * 
	 * @param numero_, valoraci�n num�rica de la oferta.
	 * @param usuario_, usuario que hace la valoraci�n.
	 */
	public ValoracionNumerica(double numero_, UsuarioRegistrado usuario_) {
		_numero = numero_;
		super.setUsuarioValoracion(usuario_);
	}
	
	/**
	 * Obtiene el n�mero de la valoraci�n.
	 * 
	 * @return n�mero de la valoraci�n.
	 */
	public double getValorNumerico() {
		
		return _numero;
	}
	
}
