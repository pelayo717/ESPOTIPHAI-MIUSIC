package sistema;


import java.util.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Clase para manejar las ofertas del sistema de alquiler de viviendas.
 * 
 * @author Nazariy Gunko
 * @author Alvaro Mor�n
 *
 */
public class Oferta implements Serializable{

	private static final long serialVersionUID = -8053072807834390253L;
	private UsuarioRegistrado _duenio; 
	private UsuarioRegistrado _comprador;
	private String descripcion;
	private Reserva[] _reserva = new Reserva[1];
	private ArrayList<Valoracion> _valoraciones = new ArrayList<Valoracion>();
	private int _fianza;
	private Boolean _reservada;
	private Boolean _contratada;
	private LocalDate _fechaCreacion;
	
	
	/**
	 * Constructor de la oferta, crea una oferta con sus datos principales.
	 * 
	 * @param descripcion_, descripcion.
	 * @param fianza_, fianza.
	 * @param reservada_, si la oferta est� reservada o no.
	 * @param contratada_, si ha sido contratada o no.
	 * @param fecha_, fecha de creaci�n.
	 */
	public Oferta(int fianza_, Boolean reservada_, Boolean contratada_, LocalDate fecha_, UsuarioRegistrado duenio_) {
		_fianza = fianza_;
		_reservada = reservada_;
		_contratada = contratada_;
		_fechaCreacion = fecha_;
		_duenio = duenio_;
	}

	/**
	 * Obtiene la valoracion media de una oferta.
	 * 
	 * @return valor media de todas las valoraciones.
	 */
	public double getValoracionMedia() {
		double total = 0;
		double aux = 0;
		int i;
		
		for(i=0; i<_valoraciones.size(); i++) {
			if(_valoraciones.get(i) instanceof ValoracionNumerica) {
			aux = ((ValoracionNumerica)_valoraciones.get(i)).getValorNumerico();
			total += aux;
			}
		}
		
		total = total/(i);
		return total;
	}
	
	/**
	 * Obtiene el array de valoraciones de una oferta.
	 * 
	 * @return valoraciones de una oferta.
	 */
	public ArrayList<Valoracion> getValoracionesOferta() {
		return _valoraciones;
	}
	
	/**
	 * Obtiene la fianza de una oferta.
	 * 
	 * @return fianza de la oferta.
	 */
	public int getFianzaOferta() {
		return _fianza;
	}
	
	/**
	 * Devuelve si la oferta esta reservada o no.
	 * 
	 * @return true en caso de que est� reservada, false si no.
	 */
	public Boolean getReservadaOferta() {
		if(_reservada == true) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Devuelve si una oferta ha sido contratada o no.
	 * 
	 * @return true si la oferta ha sido contratada, false si no.
	 */
	public Boolean getContratadaOferta() {
		if(_contratada == true) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Obtiene el comprador de la oferta actual.
	 * 
	 * @return usuario registrado comprador.
	 */
	public UsuarioRegistrado getComprador() {
		return _comprador;
	}
	
	/**
	 * Obtiene la fecha cuando se cre� la oferta.
	 * 
	 * @return fecha de creaci�n.
	 */
	public LocalDate getFechaCreacion() {
		return _fechaCreacion;
	}

	/**
	 * Obtiene la reserva de la oferta.
	 * 
	 * @return reserva de la oferta, ser� null si no se ha reservado aun.
	 */
	public Reserva getReservaOferta () {		
		return _reserva[0];
	}
	
	/**
	 * Establece una reserva sobre una oferta.
	 * 
	 * @param r1, reserva a establecer.
	 */
	public void setReserva(Reserva r1) {
		_reserva[0] = r1;
	}
	
	/**
	 * Establece un comprador sobre una oferta.
	 * 
	 * @param ur1, comprador de la oferta.
	 */
	public void setComprador(UsuarioRegistrado ur1) {
		_comprador = ur1;
	}
	
	/**
	 * Establece una oferta como contratada.
	 * 
	 */	
	public void setContratada() {
		_contratada = true;
	}
	
	/**
	 * Establece una oferta como reservada.
	 * 
	 */
	public void setReservada() {
		_reservada = true;
	}
	
	/**
	 * Anula la reserva  sobre una oferta que ha sido previamente hecha.
	 * 
	 * @return true si se ha eliminado bien, false si no existe reserva.
	 */
	public Boolean anularReserva() {
		if(_reserva[0] == null) {
			return false;
		}
		_reserva[0] = null;
		return true;
	}
	
	public void setDescripcion(String texto) {
		descripcion = texto;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	/**
	 * A�ade una valoraci�n a la oferta.
	 * 
	 * @param v, valoracion a a�adir.
	 */
	public void valorarOferta(Valoracion v) {		
		_valoraciones.add(v);
		
	}
	
	/**
	 * Obtiene el due�o de la oferta.
	 * 
	 * @return usuario registrado due�o.
	 */
	public UsuarioRegistrado getDuenioOferta () {		
		return _duenio;
	}
	
	
}
