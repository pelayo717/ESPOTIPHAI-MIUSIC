package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;

public class nTarjeta extends JFrame{
	
	 private static final long serialVersionUID = 3784588294909536811L;
	 private JPanel centro = new JPanel();
	 private JPanel sur = new JPanel();
	 private JPanel norte = new JPanel();
	 private JLabel txt = new JLabel("Introduzca el nuevo n�mero de tarjeta de cr�dito del usuario: ");
	 private JTextField texto = new JTextField();
 	 private JButton ok = new JButton("OK");
	 
	 public nTarjeta() {
		 super("Administraci�n");
		 Container cp = this.getContentPane();
		 cp.setLayout(new BorderLayout()); 
		 texto.setPreferredSize(new Dimension(200,50));
		 norte.add(txt);
		 centro.add(texto);
		 sur.add(ok);
		 cp.add(centro, BorderLayout.CENTER);
		 cp.add(sur, BorderLayout.SOUTH);
		 cp.add(norte, BorderLayout.NORTH);
		 this.setPreferredSize(new Dimension(400,180));
		 this.pack(); 
		 this.setVisible(true);
		 this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	 }
	 
	 public String getTexto() {
		 return texto.getText();
	 }
	 
	 public void setControlador(ActionListener al) {
			ok.addActionListener(al);
	 }

	public JButton getOk() {
		return ok;
	}

	public void setOk(JButton ok) {
		this.ok = ok;
	}

}