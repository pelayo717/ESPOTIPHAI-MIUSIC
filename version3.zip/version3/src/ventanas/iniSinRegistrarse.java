package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;

public class iniSinRegistrarse extends JFrame{

	private static final long serialVersionUID = 4236384875050710946L;
	private JLabel bien = new JLabel("Bienvenido, usuario sin registrar");
	private String[] bus = {"B�squeda CP","B�squeda Fechas (dd/mm/yyyy)","B�squeda Tipo Oferta"};
	private JPanel aux = new JPanel();
	private JLabel buscar = new JLabel("Caracter�sticas de b�squeda: ");
	private JButton realizar = new JButton("Buscar");
	private JTextField campo = new JTextField("", 10);
	private JButton reg = new JButton("Registrarse");
	private JComboBox<String> opciones = new JComboBox<String>(bus);
	private Container contenedor = this.getContentPane();
	
	
	public iniSinRegistrarse() {
		
		SpringLayout layout = new SpringLayout();
		aux.setLayout(layout);
		
		/*Ponemos en su sitio el bienvenido y la lista de reservas*/
		layout.putConstraint(SpringLayout.WEST, bien, 20, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, bien, 20, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, reg, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, reg, 40, SpringLayout.NORTH, this);
		
		
		/* Seteamos los campos para la b�squeda */
		layout.putConstraint(SpringLayout.WEST, buscar, 50, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, buscar, 100, SpringLayout.NORTH, this);		
		layout.putConstraint(SpringLayout.WEST, campo, 10, SpringLayout.EAST, buscar);
		layout.putConstraint(SpringLayout.NORTH, campo, 0, SpringLayout.NORTH, buscar);
		layout.putConstraint(SpringLayout.WEST, opciones, 10, SpringLayout.EAST, campo);
		layout.putConstraint(SpringLayout.NORTH, opciones, -3, SpringLayout.NORTH, campo);
		
		/*Ponemos el boton para proceder a la b�squeda */
		layout.putConstraint(SpringLayout.WEST, realizar, 250, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, realizar, 10, SpringLayout.SOUTH, opciones);
		aux.add(buscar);
		aux.add(opciones);
		aux.add(campo);
		aux.add(realizar);
		aux.add(bien);
		aux.add(reg);
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public String getTexto() {
		 return campo.getText();
	 }
	
	public String getFiltro() {
		return (String)opciones.getSelectedItem();
	}
	
	public void setControlador(ActionListener al) {
		realizar.addActionListener(al);
		reg.addActionListener(al);
	}

	public JButton getRealizar() {
		return realizar;
	}

	public void setRealizar(JButton realizar) {
		this.realizar = realizar;
	}

	public JButton getReg() {
		return reg;
	}

	public void setReg(JButton reg) {
		this.reg = reg;
	}	
}