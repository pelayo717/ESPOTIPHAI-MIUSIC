package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;

public class sugerencia extends JFrame{

	private static final long serialVersionUID = -8931593053521335503L;
	private JPanel centro = new JPanel();
	private JPanel sur = new JPanel();
	private JPanel norte = new JPanel();
	private JLabel txt = new JLabel("Esriba sus sugerencias para la oferta: ");
	private JTextField texto = new JTextField();
 	private JButton ok = new JButton("OK");
	 
	public sugerencia() {
		 super("Administraci�n");
		 Container cp = this.getContentPane();
		 cp.setLayout(new BorderLayout()); 
		 texto.setPreferredSize(new Dimension(200,50));
		 norte.add(txt);
		 centro.add(texto);
		 sur.add(ok);
		 cp.add(centro, BorderLayout.CENTER);
		 cp.add(sur, BorderLayout.SOUTH);
		 cp.add(norte, BorderLayout.NORTH);
		 this.setPreferredSize(new Dimension(400,180));
		 this.pack(); 
		 this.setVisible(true);
		 this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	 
	public String getSugerencia() {
		 return texto.getText();
	}
	 
	public void setControlador(ActionListener al) {
		ok.addActionListener(al);
	}

	public JButton getOk() {
		return ok;
	}
	
	public JTextField getTexto() {
		return texto;
	}

	public void setTexto(JTextField texto) {
		this.texto = texto;
	}

	public void setOk(JButton ok) {
		this.ok = ok;
	}

}
