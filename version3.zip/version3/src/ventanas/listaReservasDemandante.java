package ventanas;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

public class listaReservasDemandante extends JFrame {
	
	private static final long serialVersionUID = 4326409072750516182L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("Lista Reservas");
	private JButton botonSig = new JButton("Siguiente Oferta");
	private JButton botonAnt = new JButton("Oferta Anterior");
	private JButton anular = new JButton("Anular");
	private JButton contratar = new JButton("Contratar");
	private JLabel desc = new JLabel("Descripcion: ");
	private JLabel nombre = new JLabel("Reserva: ");
	private JLabel fIni = new JLabel("Fecha Inicio: ");
	private JLabel fFin = new JLabel("Fecha Fin: ");
	private JButton vol = new JButton("Volver");
	private Container contenedor = this.getContentPane();


	public listaReservasDemandante() {
		super("Book King");
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		SpringLayout eyy = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		aux.setLayout(eyy);
		
		eyy.putConstraint(SpringLayout.WEST, titulo, 165, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.NORTH, titulo, 10, SpringLayout.NORTH,this);
		
		eyy.putConstraint(SpringLayout.WEST, vol, 30, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.NORTH, vol, 30, SpringLayout.NORTH,this);
		
		/*Botones para navegar entre ofertas y realizar acciones sobre las mismas*/
		eyy.putConstraint(SpringLayout.SOUTH, botonSig, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonSig, 10, SpringLayout.EAST, botonAnt);
		eyy.putConstraint(SpringLayout.SOUTH, botonAnt, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonAnt, 120, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.NORTH, anular, 10, SpringLayout.SOUTH, fFin);
		eyy.putConstraint(SpringLayout.WEST, anular, 0, SpringLayout.WEST, fFin);
		eyy.putConstraint(SpringLayout.WEST, contratar, 10, SpringLayout.SOUTH, anular);
		eyy.putConstraint(SpringLayout.NORTH, contratar, 10, SpringLayout.SOUTH, fFin);
		
		/*Datos de la oferta*/
		eyy.putConstraint(SpringLayout.WEST, nombre, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, nombre, 120, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.WEST, desc, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, desc, 10, SpringLayout.SOUTH, nombre);
		eyy.putConstraint(SpringLayout.WEST, fIni, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, fIni, 10, SpringLayout.SOUTH, desc);
		eyy.putConstraint(SpringLayout.WEST, fFin, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, fFin, 10, SpringLayout.SOUTH, fIni);
		
		aux.add(titulo);
		aux.add(botonSig);
		aux.add(botonAnt);
		aux.add(anular);
		aux.add(contratar);
		aux.add(nombre);
		aux.add(fIni);
		aux.add(fFin);
		aux.add(vol);
		aux.add(desc);
		
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setIDReserva(int id) {
		nombre.setText("Reserva: " + id);
	}
	
	
	public void setFechaIni(String dia, String mes, String anio) {
		fIni.setText("Fecha Inicio: " + dia + "/"+ mes + "/" + anio);
	}
	
	public void setFechaFin(String dia, String mes, String anio) {
		fFin.setText("Fecha Fin: " + dia + "/" + mes + "/" + anio);
	
	}
	
	public String getFechaIni() {
		String s = fIni.getText();
		String dia, mes, anio;
		StringTokenizer cmp1 = new StringTokenizer(s, ": ");
		StringTokenizer cmp2 = new StringTokenizer(s, " ");
		dia = cmp1.nextToken();
		dia = cmp1.nextToken();
		try {
			dia = cmp1.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error en la fecha");
			return "";
		}
		mes = cmp2.nextToken();
		mes = cmp2.nextToken();
		mes = cmp2.nextToken();
		try {
			mes = cmp2.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error en la fecha");
			return "";
		}
		try {
			anio = cmp2.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error en la fecha");
			return "";
		}
		return dia + " " + mes + " " + anio;
	}

	public String getFechaFin() {
		String s = fFin.getText();
		String dia, mes, anio;
		StringTokenizer cmp1 = new StringTokenizer(s, ": ");
		StringTokenizer cmp2 = new StringTokenizer(s, " ");
		dia = cmp1.nextToken();
		dia = cmp1.nextToken();
		try {
			dia = cmp1.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error en la fecha");
			return "";
		}
		mes = cmp2.nextToken();
		mes = cmp2.nextToken();
		mes = cmp2.nextToken();
		try {
			mes = cmp2.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error en la fecha");
			return "";
		}
		try {
			anio = cmp2.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error en la fecha");
			return "";
		}
		return dia + " " + mes + " " + anio;
	}
	
	
	public void setControlador(ActionListener al) {
		botonSig.addActionListener(al);
		botonAnt.addActionListener(al);
		anular.addActionListener(al);
		contratar.addActionListener(al);	
		vol.addActionListener(al);
	}

	public JButton getBotonSiguiente() {
		return botonSig;
	}
	
	public JLabel getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc.setText(desc);;
	}

	public JButton getBotonAnterior() {
		return botonAnt;
	}

	public JButton getBotonAnular() {
		return anular;
	}
	
	public JButton getBotonContratar() {
		return contratar;
	}

	public JButton getVol() {
		return vol;
	}

	public void setVol(JButton vol) {
		this.vol = vol;
	}
	
	
}