package ventanas;

import java.awt.*;
import java.awt.event.*;
import java.util.Enumeration;

import javax.swing.*;

public class crearOferta extends JFrame{

	private static final long serialVersionUID = 3708998498539483002L;
	private JPanel aux = new JPanel();
	private String[] listaViviendas = {""};
	private JComboBox<String> viviendas = new JComboBox<String>(listaViviendas);
	private JLabel titulo = new JLabel("Creaci�n de Oferta");
	private JButton botonCrear = new JButton("Crear Oferta");
	private JButton botonVolver = new JButton("Volver Ofertas");
	private JLabel precio = new JLabel("Precio: ");
	private JTextField precioRelleno = new JTextField("", 10);
	private JLabel fianza = new JLabel("Fianza: ");
	private JTextField fianzaRellena = new JTextField("", 10);
	private JLabel fechaIni = new JLabel("Fecha Inicio: ");
	private JTextField fechaIniRellena = new JTextField("", 10);
	private Container contenedor = this.getContentPane();
	private JRadioButton vacacional = new JRadioButton("Vacacional");
	private JRadioButton mensual = new JRadioButton("Mensual");
	private ButtonGroup opciones = new ButtonGroup();
	private JLabel tipo = new JLabel("Tipo de oferta: ");

	
	public crearOferta() {
		super("Book King");
		SpringLayout layout = new SpringLayout();
		aux.setLayout(layout);
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		contenedor.setLayout(new BorderLayout());
		
		opciones.add(vacacional);
		opciones.add(mensual);

		/* Ponemos el titulo en su sitio */
		layout.putConstraint(SpringLayout.WEST, titulo, 165, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, titulo, 20, SpringLayout.NORTH, this);
		
		/* Ponemos en la ventana los campos a rellenar de la vivienda */
		layout.putConstraint(SpringLayout.WEST, botonVolver,35, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 80, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, botonCrear, 200, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, botonCrear, 300, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, viviendas, 270, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, viviendas,220, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, precio, 200, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, precio, 100, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, precioRelleno, 10, SpringLayout.EAST, precio);
		layout.putConstraint(SpringLayout.NORTH, precioRelleno, 0, SpringLayout.NORTH, precio);
		layout.putConstraint(SpringLayout.WEST, fianza, 0, SpringLayout.WEST, precio);
		layout.putConstraint(SpringLayout.NORTH, fianza, 8, SpringLayout.SOUTH, precio);
		layout.putConstraint(SpringLayout.WEST, fianzaRellena, 10, SpringLayout.EAST, precio);
		layout.putConstraint(SpringLayout.NORTH, fianzaRellena, 0, SpringLayout.NORTH, fianza);
		layout.putConstraint(SpringLayout.WEST, fechaIni, 0, SpringLayout.WEST, precio);
		layout.putConstraint(SpringLayout.NORTH, fechaIni, 8, SpringLayout.SOUTH, fianza);
		layout.putConstraint(SpringLayout.WEST, fechaIniRellena, 10, SpringLayout.EAST, fechaIni);
		layout.putConstraint(SpringLayout.NORTH, fechaIniRellena, 0, SpringLayout.NORTH, fechaIni);
		layout.putConstraint(SpringLayout.WEST, tipo, 0, SpringLayout.WEST, fechaIni);
		layout.putConstraint(SpringLayout.NORTH, tipo, 15, SpringLayout.SOUTH, fechaIni);
		layout.putConstraint(SpringLayout.WEST, vacacional, 10, SpringLayout.EAST, tipo);
		layout.putConstraint(SpringLayout.NORTH, vacacional, 20, SpringLayout.NORTH, fechaIni);
		layout.putConstraint(SpringLayout.WEST, mensual, 10, SpringLayout.EAST, tipo);
		layout.putConstraint(SpringLayout.NORTH, mensual, 20, SpringLayout.NORTH, vacacional);
		

		aux.add(titulo);
		aux.add(botonCrear);
		aux.add(botonVolver);
		aux.add(precio);
		aux.add(precioRelleno);
		aux.add(fianza);
		aux.add(fianzaRellena);
		aux.add(fechaIni);
		aux.add(fechaIniRellena);
		aux.add(mensual);
		aux.add(vacacional);
		aux.add(tipo);
		aux.add(viviendas);
		
		contenedor.add(aux);
		
		/* Establecemos los b�sicos del JFrame */
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setControlador(ActionListener al) {
		botonCrear.addActionListener(al);
		botonVolver.addActionListener(al);	
	}
	
	public JButton getCrearOferta() {
		return botonCrear;
	}
	
	public JButton getVolver() {
		return botonVolver;
	}

	public JTextField getPrecioRelleno() {
		return precioRelleno;
	}

	public void setPrecioRelleno(JTextField precioRelleno) {
		this.precioRelleno = precioRelleno;
	}

	public JTextField getFianzaRellena() {
		return fianzaRellena;
	}

	public void setFianzaRellena(JTextField fianzaRellena) {
		this.fianzaRellena = fianzaRellena;
	}

	public JTextField getFechaIniRellena() {
		return fechaIniRellena;
	}
	
	public void setViviendas(String Vivienda) {
		viviendas.addItem(Vivienda);
	}

	public void setFechaIniRellena(JTextField fechaIniRellena) {
		this.fechaIniRellena = fechaIniRellena;
	}
	
	public String getVivienda() {
		return (String)viviendas.getSelectedItem();
	}
	

	public ButtonGroup getOpciones() {
		return opciones;
	}
	
	

	public JRadioButton getVacacional() {
		return vacacional;
	}

	public void setVacacional(JRadioButton vacacional) {
		this.vacacional = vacacional;
	}

	public JRadioButton getMensual() {
		return mensual;
	}
	
	public String getTipo() {
 		Enumeration<AbstractButton> botones = opciones.getElements();
 		String val = "";
 		while(botones.hasMoreElements()) {
 			JRadioButton b = (JRadioButton)botones.nextElement();
 			if(b.isSelected()) {
 				val = b.getText();
 			}
 		}
 		return val;
 	}

	public void setMensual(JRadioButton mensual) {
		this.mensual = mensual;
	}

	public void setOpciones(ButtonGroup opciones) {
		this.opciones = opciones;
	}
}
