package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.swing.*;

public class cambiarTarjetaCredito extends JFrame{

	private static final long serialVersionUID = 5691777494441029294L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("Usuarios Bloqueados");
	private JButton botonNO = new JButton("Nuevas Ofertas");
	private JButton botonSig = new JButton("Siguiente Usuario");
	private JButton botonAnt = new JButton("Usuario Anterior");
	private JButton botonCambiar = new JButton("Cambiar N�mero Tarjeta");
	private JLabel nombre = new JLabel("Nombre: ");
	private JLabel apellido = new JLabel("Apellidos: ");
	private JLabel dniU = new JLabel("Dni: ");
	private JLabel tarjeta = new JLabel("Tarjeta Credito Actual: ");
	private Container contenedor = this.getContentPane();
	
	
	public cambiarTarjetaCredito() {
		super("Book King");
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		SpringLayout eyy = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		aux.setLayout(eyy);
		
		eyy.putConstraint(SpringLayout.WEST, botonNO, 30, SpringLayout.WEST, aux);
		eyy.putConstraint(SpringLayout.NORTH, botonNO, 150, SpringLayout.NORTH, aux);
		eyy.putConstraint(SpringLayout.WEST, titulo, 165, SpringLayout.NORTH,this);
		eyy.putConstraint(SpringLayout.NORTH, titulo, 10, SpringLayout.NORTH,this);
		
		/*Botones para navegar entre ofertas*/
		eyy.putConstraint(SpringLayout.SOUTH, botonSig, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonSig, 10, SpringLayout.EAST, botonAnt);
		eyy.putConstraint(SpringLayout.SOUTH, botonAnt, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonAnt, 120, SpringLayout.SOUTH, this);
		
		/*Datos del usuario*/
		eyy.putConstraint(SpringLayout.WEST, nombre, 240, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, nombre, 120, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.WEST, apellido, 240, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, apellido, 10, SpringLayout.SOUTH, nombre);
		eyy.putConstraint(SpringLayout.WEST, dniU, 240, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, dniU, 10, SpringLayout.SOUTH, apellido);
		eyy.putConstraint(SpringLayout.WEST, tarjeta, 240, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, tarjeta, 10, SpringLayout.SOUTH, dniU);
		
		/*Boton de cambiar la tarjeta de cr�dito*/
		eyy.putConstraint(SpringLayout.WEST, botonCambiar, 280, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, botonCambiar, 280, SpringLayout.NORTH, this);

		
		aux.add(botonNO);
		aux.add(titulo);
		aux.add(botonSig);
		aux.add(botonAnt);
		aux.add(nombre);
		aux.add(apellido);
		aux.add(dniU);
		aux.add(tarjeta);
		aux.add(botonCambiar);
		
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setNombreUsuario(String texto) {
		nombre.setText(texto);
	}
	
	public void setApellidoUsuario(String texto) {
		apellido.setText(texto);
	}
	
	public void setDNIUsuario(String texto) {
		dniU.setText(texto);
	}
	
	public void setTarjetaCredito(String texto) {
		tarjeta.setText(texto);
	}
	public String getDNIUsuario() {
		String s = dniU.getText();
		String def;
		StringTokenizer cmp = new StringTokenizer(s, ": ");
		def = cmp.nextToken();
		try {
			def = cmp.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error, el usuario no tiene DNI");
			return "";
		}
		return def;
	}
	
	
	public void setControlador(ActionListener ctc) {
		botonNO.addActionListener(ctc);
		botonSig.addActionListener(ctc);
		botonAnt.addActionListener(ctc);
		botonCambiar.addActionListener(ctc);
		
	}
	
	public JButton getBotonNuevaOferta() {
		return botonNO;
	}
	
	public JButton getBotonSiguienteUsuario() {
		return botonSig;
	}
	
	public JButton getBotonUsuarioAnterior() {
		return botonAnt;
	}
	
	public JButton getCambiarTarjetaCredito() {
		return botonCambiar;
	}


}