package ventanas;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class buzonMensajes extends JFrame{

	private static final long serialVersionUID = -1389714415302213327L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("Buz�n de mensajes");
	private JButton botonSig = new JButton("Siguiente Mensaje");
	private JButton botonAnt = new JButton("Mensaje Anterior");
	private JButton volver = new JButton("Volver");
	private JLabel envio = new JLabel("De: ");
	private JLabel asunto = new JLabel("Asunto: ");
	private JLabel mensaje = new JLabel("Mensaje: ");
	private JLabel contenido = new JLabel("");
	private Container contenedor = this.getContentPane();


	public buzonMensajes() {
		super("Book King");
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		SpringLayout layout = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		aux.setLayout(layout);
		
		layout.putConstraint(SpringLayout.WEST, titulo, 170, SpringLayout.WEST,this);
		layout.putConstraint(SpringLayout.NORTH, titulo, 20, SpringLayout.NORTH,this);
		
		layout.putConstraint(SpringLayout.WEST, volver, 20, SpringLayout.WEST,this);
		layout.putConstraint(SpringLayout.NORTH, volver, 60, SpringLayout.NORTH,this);
		layout.putConstraint(SpringLayout.WEST, botonSig, 165, SpringLayout.WEST,this);
		layout.putConstraint(SpringLayout.NORTH, botonSig, 270, SpringLayout.NORTH,this);
		layout.putConstraint(SpringLayout.WEST, botonAnt, 10, SpringLayout.EAST, botonSig);
		layout.putConstraint(SpringLayout.NORTH, botonAnt, 0, SpringLayout.NORTH, botonSig);
				
		layout.putConstraint(SpringLayout.WEST, envio, 170, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, envio, 100, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, asunto, 0, SpringLayout.WEST, envio);
		layout.putConstraint(SpringLayout.NORTH, asunto, 10, SpringLayout.SOUTH, envio);
		layout.putConstraint(SpringLayout.WEST, mensaje, 0, SpringLayout.WEST, envio);
		layout.putConstraint(SpringLayout.NORTH, mensaje, 10, SpringLayout.SOUTH, asunto);
		layout.putConstraint(SpringLayout.WEST, contenido, 0, SpringLayout.WEST, envio);
		layout.putConstraint(SpringLayout.NORTH, contenido, 10, SpringLayout.SOUTH, mensaje);
		
		aux.add(titulo);
		aux.add(botonSig);
		aux.add(botonAnt);
		aux.add(volver);
		aux.add(envio);
		aux.add(asunto);
		aux.add(mensaje);
		aux.add(contenido);
		
		contenedor.add(aux);
		/* Establecemos los b�sicos del JFrame */
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}

	public void setControlador(ActionListener al) {
		botonSig.addActionListener(al);
		botonAnt.addActionListener(al);
		volver.addActionListener(al);
	}

	public void setContenido(String text) {
		contenido.setText(text);
	}
	
	public JButton getBotonSig() {
		return botonSig;
	}

	public void setBotonSig(JButton botonSig) {
		this.botonSig = botonSig;
	}

	public JButton getBotonAnt() {
		return botonAnt;
	}

	public void setBotonAnt(JButton botonAnt) {
		this.botonAnt = botonAnt;
	}

	public JButton getVolver() {
		return volver;
	}

	public void setVolver(JButton volver) {
		this.volver = volver;
	}

	public JLabel getEnvio() {
		return envio;
	}

	public void setEnvio(String envio) {
		this.envio.setText(envio);
	}

	public JLabel getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto.setText(asunto);
	}
	
	public void setMensaje(String texto) {
		this.mensaje.setText(texto);
	}
}
