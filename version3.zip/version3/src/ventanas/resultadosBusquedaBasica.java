package ventanas;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

public class resultadosBusquedaBasica extends JFrame {
	
	private static final long serialVersionUID = 3651474173426696745L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("Resultados B�squeda");
	private JButton botonSig = new JButton("Siguiente Oferta");
	private JButton botonAnt = new JButton("Oferta Anterior");
	private JButton volver = new JButton("Volver");
	private JLabel nombre = new JLabel("Oferta: ");
	private JLabel precio = new JLabel("Precio: ");
	private JLabel desc = new JLabel("Descripci�n: ");
	private JLabel fianza = new JLabel("Fianza: ");
	private JLabel valoracion = new JLabel("Valoraci�n: ");
	private Container contenedor = this.getContentPane();


	public resultadosBusquedaBasica() {
		super("Book King");
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		SpringLayout eyy = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		aux.setLayout(eyy);
		
		eyy.putConstraint(SpringLayout.WEST, titulo, 165, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.NORTH, titulo, 10, SpringLayout.NORTH, this);

		eyy.putConstraint(SpringLayout.NORTH, volver, 0, SpringLayout.NORTH, botonAnt);
		eyy.putConstraint(SpringLayout.WEST, volver, 40, SpringLayout.SOUTH, this);
		/*Botones para navegar entre ofertas y realizar acciones sobre las mismas*/
		eyy.putConstraint(SpringLayout.SOUTH, botonSig, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonSig, 10, SpringLayout.EAST, botonAnt);
		eyy.putConstraint(SpringLayout.SOUTH, botonAnt, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonAnt, 120, SpringLayout.SOUTH, this);
		
		/*Datos de la oferta*/
		eyy.putConstraint(SpringLayout.WEST, nombre, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, nombre, 120, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.WEST, desc, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, desc, 10, SpringLayout.SOUTH, nombre);
		eyy.putConstraint(SpringLayout.WEST, fianza, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, fianza, 10, SpringLayout.SOUTH, desc);
		eyy.putConstraint(SpringLayout.WEST, valoracion, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, valoracion, 10, SpringLayout.SOUTH, fianza);
		eyy.putConstraint(SpringLayout.WEST, precio, 160, SpringLayout.WEST, this);
		eyy.putConstraint(SpringLayout.NORTH, precio, 10, SpringLayout.SOUTH, valoracion);
		
		aux.add(titulo);
		aux.add(botonSig);
		aux.add(botonAnt);
		aux.add(nombre);
		aux.add(desc);
		aux.add(fianza);
		aux.add(valoracion);
		aux.add(volver);
		aux.add(precio);
		
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setIDOferta(int id) {
		nombre.setText("Oferta: " + id);
	}
	
	public void setDescOferta(String texto) {
		desc.setText("Descripci�n: " + texto);
	}
	
	public void setFianza(int f) {
		fianza.setText("Fianza: " + f);
	}
	
	public void setValoracion(double ValM) {
		valoracion.setText("Valoracion: " + ValM);
	}
	public int getIDOferta() {
		String s = nombre.getText();
		String def;
		StringTokenizer cmp = new StringTokenizer(s, ": ");
		def = cmp.nextToken();
		try {
			def = cmp.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error, la oferta no tiene ID");
			return 0;
		}
		return Integer.parseInt(def);
	}

	 public void setControlador(ActionListener al) {
		botonSig.addActionListener(al);
		botonAnt.addActionListener(al);	
		volver.addActionListener(al);
		
	}
	 
	public JButton getBotonSiguiente() {
		return botonSig;
	}
	
	public JButton getBotonAnterior() {
		return botonAnt;
	}

	public JButton getVolver() {
		return volver;
	}
	public JLabel getPrecio() {
		return precio;
	}

	public void setPrecio(String precio) {
		this.precio.setText(precio);
	}
	
}