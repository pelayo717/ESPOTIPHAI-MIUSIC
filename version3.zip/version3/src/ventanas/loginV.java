package ventanas;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class loginV extends JFrame {

	private static final long serialVersionUID = -8987960506470799859L;
	private JLabel dni = new JLabel("DNI : ");	
	private JLabel contra = new JLabel("Contrase�a: ");
	private final JTextField campoDni = new JTextField(10);
	private final JPasswordField campoContra = new JPasswordField(10);
	private JButton login = new JButton("Login");
	private JButton entrarSinReg = new JButton("Entrar sin registrarse");
	private Container contenedor = this.getContentPane();

	
	public loginV() {
		super("Book King login");
		contenedor.setLayout(new FlowLayout());
		contenedor.add(dni);
		contenedor.add(campoDni);
		contenedor.add(contra);
		contenedor.add(campoContra);
		contenedor.add(login);
		contenedor.add(entrarSinReg);
		
		this.setVisible(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(400,150);
		this.setVisible(true);
	}
	
	public void setControlador(ActionListener al) {
		login.addActionListener(al);
		entrarSinReg.addActionListener(al);
	}

	public JButton getLogin() {
		return login;
	}

	public void setLogin(JButton login) {
		this.login = login;
	}

	public JButton getEntrarSinReg() {
		return entrarSinReg;
	}

	public void setEntrarSinReg(JButton entrarSinReg) {
		this.entrarSinReg = entrarSinReg;
	}

	public JTextField getCampoDni() {
		return campoDni;
	}

	public JTextField getCampoContra() {
		return campoContra;
	}
		
	
//		public void setControlador(Acttion Listener c){
//           login.addActio(c);
//			 entrarSinReg.addActionListener();
//		}
//				new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						s1 = Sistema.getSistema();
//						if(s1.login(campoDni.getText(), campoContra.getText())) {
//							JOptionPane.showMessageDialog(null, "Entrando al sistema como usuario registrado...");
//							ventana.setVisible(false);
//						}
//
//					}	
//				}
//			);
//		
//		entrarSinReg.addActionListener(
//				new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						JOptionPane.showMessageDialog(null, "Entrando como usuario no registrado");
//						ventana.setVisible(false);
//					}	
//				}
//			);
		
		
		
	}