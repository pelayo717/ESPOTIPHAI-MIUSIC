package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;

public class iniOfertante extends JFrame{

	private static final long serialVersionUID = -6347993461888036663L;
	private JLabel bien = new JLabel("Bienvenido Ofertante");
	private String[] bus = {"B�squeda CP","B�squeda Fechas","B�squeda Tipo Oferta", "B�squeda Reservadas", "B�squeda Contratadas"};
	private JPanel aux = new JPanel();
	private JLabel buscar = new JLabel("Caracter�sticas de b�squeda: ");
	private JButton logout = new JButton("Logout");
	private JButton realizar = new JButton("Buscar");
	private JTextField campo = new JTextField("", 10);
	private JButton buzon = new JButton("Buz�n");
	private JButton ofertar = new JButton("Ofertar");
	private JButton crearVivienda = new JButton("Crear Vivienda");
	private JComboBox<String> opciones = new JComboBox<String>(bus);
	private Container contenedor = this.getContentPane();
	
	
	public iniOfertante() {
		
		SpringLayout layout = new SpringLayout();
		aux.setLayout(layout);
		
		/*Ponemos en su sitio el bienvenido y la lista de reservas*/
		layout.putConstraint(SpringLayout.WEST, bien, 20, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, bien, 20, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, ofertar, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, ofertar, 40, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, crearVivienda, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, crearVivienda, 10, SpringLayout.SOUTH, ofertar);
		layout.putConstraint(SpringLayout.WEST, buzon, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, buzon, 10, SpringLayout.SOUTH, crearVivienda);
		layout.putConstraint(SpringLayout.WEST, logout, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, logout, 270, SpringLayout.NORTH, this);
		
		
		/* Seteamos los campos para la b�squeda */
		layout.putConstraint(SpringLayout.WEST, buscar, 50, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, buscar, 200, SpringLayout.NORTH, this);		
		layout.putConstraint(SpringLayout.WEST, campo, 10, SpringLayout.EAST, buscar);
		layout.putConstraint(SpringLayout.NORTH, campo, 0, SpringLayout.NORTH, buscar);
		layout.putConstraint(SpringLayout.WEST, opciones, 10, SpringLayout.EAST, campo);
		layout.putConstraint(SpringLayout.NORTH, opciones, -3, SpringLayout.NORTH, campo);
		
		/*Ponemos el boton para proceder a la b�squeda */
		layout.putConstraint(SpringLayout.WEST, realizar, 250, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, realizar, 10, SpringLayout.SOUTH, opciones);
		aux.add(buscar);
		aux.add(opciones);
		aux.add(campo);
		aux.add(realizar);
		aux.add(bien);
		aux.add(buzon);
		aux.add(ofertar);
		aux.add(crearVivienda);
		contenedor.add(aux);
		aux.add(logout);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public String getTexto() {
		 return campo.getText();
	 }
	
	public String getFiltro() {
		return (String)opciones.getSelectedItem();
	}
	
	
	
	public JButton getRealizar() {
		return realizar;
	}

	public void setRealizar(JButton realizar) {
		this.realizar = realizar;
	}

	public JButton getBuzon() {
		return buzon;
	}

	public void setBuzon(JButton buzon) {
		this.buzon = buzon;
	}

	public JButton getOfertar() {
		return ofertar;
	}

	public void setOfertar(JButton ofertar) {
		this.ofertar = ofertar;
	}

	public JButton getCrearVivienda() {
		return crearVivienda;
	}

	public void setCrearVivienda(JButton crearVivienda) {
		this.crearVivienda = crearVivienda;
	}

	public void setControlador(ActionListener al) {
		buzon.addActionListener(al);
		ofertar.addActionListener(al);
		crearVivienda.addActionListener(al);
		logout.addActionListener(al);
	}
	public JButton getLogout() {
		return logout;
	}
}