package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.*;

public class valoracion extends JFrame{
	
	private static final long serialVersionUID = 2971797556205130869L;
	private JPanel centro = new JPanel();
	private JPanel sur = new JPanel();
	private JPanel norte = new JPanel();
	private JLabel txt = new JLabel("Seleccione la valoraci�n: ");
	private JButton ok = new JButton("OK");
 	private JRadioButton val1 = new JRadioButton("1");
 	private JRadioButton val2 = new JRadioButton("2");
 	private JRadioButton val3 = new JRadioButton("3");
 	private JRadioButton val4 = new JRadioButton("4");
 	private JRadioButton val5 = new JRadioButton("5");
 	private ButtonGroup grupo = new ButtonGroup();
	
 	public valoracion() {
		 super("Valoraci�n");
		 Container cp = this.getContentPane();
		 cp.setLayout(new BorderLayout()); 
		 norte.add(txt);
		 val1.setSelected(true);
		 grupo.add(val1);
		 grupo.add(val2);
		 grupo.add(val3);
		 grupo.add(val4);
		 grupo.add(val5);
		 centro.setLayout(new BoxLayout(centro, 1));
		 centro.add(val1);
		 centro.add(val2);
		 centro.add(val3);
		 centro.add(val4);
		 centro.add(val5);
		 sur.add(ok);
		 cp.add(centro, BorderLayout.CENTER);
		 cp.add(sur, BorderLayout.SOUTH);
		 cp.add(norte, BorderLayout.NORTH);
		 this.setPreferredSize(new Dimension(300,250));
		 this.pack(); 
		 this.setVisible(true);
		 this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	 }

 	public int getValoracion() {
 		Enumeration<AbstractButton> botones = grupo.getElements();
 		String val = "";
 		while(botones.hasMoreElements()) {
 			JRadioButton b = (JRadioButton)botones.nextElement();
 			if(b.isSelected()) {
 				val = b.getText();
 			}
 		}
 		int v = Integer.parseInt(val);
 		return v;
 	}
 	
 	public void setControlador(ActionListener al) {
		ok.addActionListener(al);
	}

	public JButton getOk() {
		return ok;
	}

	public void setOk(JButton ok) {
		this.ok = ok;
	}

	public ButtonModel getSeleccion() {
		return grupo.getSelection();
	}

	public void setGrupo(ButtonGroup grupo) {
		this.grupo = grupo;
	}
 	
 	
}