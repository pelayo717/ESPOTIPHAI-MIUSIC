package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;

public class iniDemandante extends JFrame{

	private static final long serialVersionUID = 4912724407238352835L;
	private JLabel bien = new JLabel("Bienvenido Demandante");
	private String[] bus = {"B�squeda CP","B�squeda Fechas (dd/mm/yyyy)","B�squeda Tipo Oferta", "B�squeda Reservadas", "B�squeda Contratadas", "B�squeda Pagadas"};
	private JPanel aux = new JPanel();
	private JLabel buscar = new JLabel("Caracter�sticas de b�squeda: ");
	private JButton logout = new JButton("Logout");
	private JButton realizar = new JButton("Buscar");
	private JTextField campo = new JTextField("", 10);
	private JButton lista = new JButton("Lista Reservas");
	private JComboBox<String> opciones = new JComboBox<String>(bus);
	private Container contenedor = this.getContentPane();
	
	
	public iniDemandante() {
		super("Book King");
		SpringLayout layout = new SpringLayout();
		aux.setLayout(layout);
		
		/*Ponemos en su sitio el bienvenido y la lista de reservas*/
		layout.putConstraint(SpringLayout.WEST, bien, 20, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, bien, 20, SpringLayout.NORTH,this);
		layout.putConstraint(SpringLayout.WEST, lista, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, lista, 40, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, logout, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, logout, 270, SpringLayout.NORTH, this);
		
		
		/* Seteamos los campos para la b�squeda */
		layout.putConstraint(SpringLayout.WEST, buscar, 50, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, buscar, 100, SpringLayout.NORTH, this);		
		layout.putConstraint(SpringLayout.WEST, campo, 10, SpringLayout.EAST, buscar);
		layout.putConstraint(SpringLayout.NORTH, campo, 0, SpringLayout.NORTH, buscar);
		layout.putConstraint(SpringLayout.WEST, opciones, 10, SpringLayout.EAST, campo);
		layout.putConstraint(SpringLayout.NORTH, opciones, -3, SpringLayout.NORTH, campo);
		
		/*Ponemos el boton para proceder a la b�squeda */
		layout.putConstraint(SpringLayout.WEST, realizar, 250, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, realizar, 10, SpringLayout.SOUTH, opciones);
		aux.add(buscar);
		aux.add(opciones);
		aux.add(campo);
		aux.add(realizar);
		aux.add(bien);
		aux.add(lista);
		aux.add(logout);
		
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setControlador(ActionListener al) {
		realizar.addActionListener(al);
		lista.addActionListener(al);
		opciones.addActionListener(al);
		logout.addActionListener(al);
	}
	
	public String getTexto() {
		 return campo.getText();
	}
	
	public String getFiltro() {
		return (String)opciones.getSelectedItem();
	}

	public JButton getRealizar() {
		return realizar;
	}

	public void setRealizar(JButton realizar) {
		this.realizar = realizar;
	}

	public JButton getLista() {
		return lista;
	}

	public void setLista(JButton lista) {
		this.lista = lista;
	}
	public JButton getLogout() {
		return logout;
	}
	
	
}
