package ventanas;

import java.time.LocalDate;

import javax.swing.JOptionPane;

public class prueba {

	public static void main(String[] args) {
		comentarOferta c = new comentarOferta();
		//loginV v2 = new loginV();
		//sugerencia j = new sugerencia();
//		nTarjeta h = new nTarjeta();
//		respuesta r = new respuesta();
//	crearOferta co = new crearOferta();
//		crearOferta c = new crearOferta();
//		iniSinRegistrarse i = new iniSinRegistrarse();
//		comentarios c = new comentarios();
//		cambiarTarjetaCredito bm = new cambiarTarjetaCredito();
//		iniDemandanteOfertante i = new iniDemandanteOfertante();
//		iniGerente v1 = new iniGerente();
//	iniOfertante z = new iniOfertante();
//		iniDemandante v = new iniDemandante();
//		v1.setIDOferta(33);
//		iniGerente v1 = new iniGerente();
//		iniSinRegistrarse i = new iniSinRegistrarse();
//		buzonMensajes b = new buzonMensajes();
//		rearOferta o1 = new crearOferta();
		//ventanaComentarios v1 = new ventanaComentarios();
		//respuestaComentarios u = new respuestaComentarios();
		//crearOferta o1 = new crearOferta();
		//vistaIniSinRegistrarse v1 = new vistaIniSinRegistrarse();
		//String n = v1.getFiltro();
		//v1.crearVentanaLogin();
		//vistaIniOfertante j = new vistaIniOfertante();
		//cambiarTarjetaCredito u = new cambiarTarjetaCredito();
		//u.setDNIUsuario("1234125fcff");
		//String s = u.getDNIUsuario();
		//resultadosBusquedaBasica d = new resultadosBusquedaBasica();
		//d.setIDOferta(33);
		//int n = d.getIDOferta();
//		v1.setDescripcionOferta("Casopl�n bro");
//		v1.setDireccionOferta("Calle Castedo el mejor");
//		v1.setDue�oOferta("Andrei Constantin");
//		v1.setCodigoPostalOferta("222");
		//ventanaComentario vent = new ventanaComentario();
		//String s = vent.getComentario();
		//System.out.println(n);
		//cambiarTarjetaCredito c = new cambiarTarjetaCredito();
		//anadirComentario c = new anadirComentario();
//		/resultadosBusquedaVIP n = new resultadosBusquedaVIP();
		//respuestaComentarios c = new respuestaComentarios();
		//respuesta n = new respuesta();
		//resultadosBusquedaVIP a = new resultadosBusquedaVIP();
		//valoracion v1 = new valoracion();
		//sugerencia s = new sugerencia();
		//anadirComentario a1 = new anadirComentario();
//		comentarOferta a2 = new comentarOferta();
		//resultadosBusquedaBasica b = new resultadosBusquedaBasica();
		//buzonMensajes b = new buzonMensajes();
//		respuestaComentarios t = new respuestaComentarios();
	}

}
