package ventanas;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.*;

public class crearVivienda extends JFrame {

	private static final long serialVersionUID = 2927708849989323375L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("A�adir Vivienda");
	private JButton botonAlta = new JButton("Dar de alta");
	private JButton atras = new JButton("Atr�s");
	private JLabel desc = new JLabel("Descripci�n: ");
	private JTextField descripcionNueva = new JTextField("", 10);
	private JLabel direccion = new JLabel("Direcci�n: ");
	private JTextField direccionNueva = new JTextField("", 10);
	private JLabel codigoP = new JLabel("C�digo Postal: ");
	private JTextField codigoPostNuevo = new JTextField("", 10);
	private Container contenedor = this.getContentPane();
	
	public crearVivienda() {
		super("Book King");
		SpringLayout layout = new SpringLayout();
		aux.setLayout(layout);
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		contenedor.setLayout(new BorderLayout());

		/* Ponemos el titulo en su sitio */
		layout.putConstraint(SpringLayout.WEST, titulo, 165, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.NORTH, titulo, 30, SpringLayout.NORTH, this);
		
		/* Ponemos en la ventana los campos a rellenar de la vivienda */
		layout.putConstraint(SpringLayout.WEST, desc,170, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, desc, 130, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, descripcionNueva, 10, SpringLayout.EAST, desc);
		layout.putConstraint(SpringLayout.NORTH, descripcionNueva, 0, SpringLayout.NORTH, desc);
		layout.putConstraint(SpringLayout.WEST, direccion, 0, SpringLayout.WEST, desc);
		layout.putConstraint(SpringLayout.NORTH, direccion, 8, SpringLayout.SOUTH, desc);
		layout.putConstraint(SpringLayout.WEST, direccionNueva, 10, SpringLayout.EAST, direccion);
		layout.putConstraint(SpringLayout.NORTH, direccionNueva, 0, SpringLayout.NORTH, direccion);
		layout.putConstraint(SpringLayout.WEST, codigoP, 0, SpringLayout.WEST, desc);
		layout.putConstraint(SpringLayout.NORTH, codigoP, 8, SpringLayout.SOUTH, direccionNueva);
		layout.putConstraint(SpringLayout.WEST, codigoPostNuevo, 10, SpringLayout.EAST, codigoP);
		layout.putConstraint(SpringLayout.NORTH, codigoPostNuevo, 0, SpringLayout.NORTH, codigoP);
		
		
		/* Ponemos el boton para dar de alta la vivienda */
		layout.putConstraint(SpringLayout.WEST, botonAlta, 220, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, botonAlta, 230, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, atras, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, atras, 280, SpringLayout.SOUTH, this);
		
		/* A�adimos los componentes al panel */
		aux.add(titulo);
		aux.add(desc);
		aux.add(descripcionNueva);
		aux.add(codigoP);
		aux.add(codigoPostNuevo);
		aux.add(botonAlta);
		aux.add(atras);
		aux.add(direccion);
		aux.add(direccionNueva);
		
		contenedor.add(aux);
		/* Establecemos los b�sicos del JFrame */
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setControlador(ActionListener al) {
		botonAlta.addActionListener(al);
		atras.addActionListener(al);	
	}
	
	public JButton getBotonCrear() {
		return botonAlta;
	}

	public JButton getBotonVolver() {
		return atras;
	}

	public JTextField getDescripcionNueva() {
		return descripcionNueva;
	}

	public void setDescripcionNueva(JTextField descripcionNueva) {
		this.descripcionNueva = descripcionNueva;
	}
	
	public JTextField getCodigoPostNuevo() {
		return codigoPostNuevo;
	}

	public void setCodigoPostNuevo(JTextField codigoPostNuevo) {
		this.codigoPostNuevo = codigoPostNuevo;
	}

	public JTextField getDireccionNueva() {
		return direccionNueva;
	}

	public void setDireccionNueva(JTextField direccionNueva) {
		this.direccionNueva = direccionNueva;
	}
	
	
	
	
}
