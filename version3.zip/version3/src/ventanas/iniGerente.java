package ventanas;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.swing.*;

public class iniGerente extends JFrame{

	private static final long serialVersionUID = 1340490738710521781L;
	private JPanel aux = new JPanel();
	private JPanel medio = new JPanel();
	private Container contenedor = this.getContentPane();
	private JButton logout = new JButton ("Logout");
	private JLabel titulo = new JLabel("Ofertas a aceptar");
	private JButton botonBloq = new JButton("Usuarios Bloqueados");
	private JButton botonSig = new JButton("Siguiente Oferta");
	private JButton botonAnt = new JButton("Oferta Anterior");
	private JButton botonA = new JButton("Aceptar");
	private JButton botonR = new JButton("Rechazar");
	private JButton botonS = new JButton("Sugerir");
	private JLabel nombre = new JLabel("Oferta:");
	private JLabel descripcion = new JLabel("Descripci�n: ");
	private JLabel direccion = new JLabel("Direcci�n: ");
	private JLabel duenio = new JLabel("Due�o: ");
	private JLabel codigoPostal = new JLabel ("C�digo Postal: ");
	private JLabel precio = new JLabel ("Precio: ");
	private JLabel fianza = new JLabel ("Fianza: ");
	
	public iniGerente() {
		super("Book King");
		Font f1 = new Font(null,20, 30);
		titulo.setFont(f1);
		SpringLayout prueba = new SpringLayout();
		SpringLayout prueba2 = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		medio.setLayout(prueba2);
		aux.setLayout(prueba);
		

		prueba.putConstraint(SpringLayout.WEST, logout, 30, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, logout, 230, SpringLayout.NORTH, this);
		
		
		prueba.putConstraint(SpringLayout.WEST, botonBloq, 30, SpringLayout.WEST, aux);
		prueba.putConstraint(SpringLayout.NORTH, botonBloq, 150, SpringLayout.NORTH, aux);
		prueba.putConstraint(SpringLayout.WEST, titulo, 180, SpringLayout.NORTH, this);
		
		/*Botones para navegar entre ofertas */
		prueba.putConstraint(SpringLayout.SOUTH, botonSig, 310, SpringLayout.SOUTH, this);
		prueba.putConstraint(SpringLayout.WEST, botonSig, 10, SpringLayout.EAST, botonAnt);
		prueba.putConstraint(SpringLayout.SOUTH, botonAnt, 310, SpringLayout.SOUTH, this);
		prueba.putConstraint(SpringLayout.WEST, botonAnt, 120, SpringLayout.SOUTH, this);
		
		
		/* Botones para las ofertas*/
		prueba.putConstraint(SpringLayout.WEST, botonA, 280, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, botonA, 280, SpringLayout.NORTH, this);
		prueba.putConstraint(SpringLayout.WEST, botonR, 5, SpringLayout.EAST, botonA);
		prueba.putConstraint(SpringLayout.NORTH, botonR,280, SpringLayout.NORTH, this);
		prueba.putConstraint(SpringLayout.WEST, botonS, 5, SpringLayout.EAST, botonR);
		prueba.putConstraint(SpringLayout.NORTH, botonS, 280, SpringLayout.NORTH, this);
		
		/*Caracteristicas de la oferta y la vivienda*/
		prueba.putConstraint(SpringLayout.WEST, nombre, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, nombre, 80, SpringLayout.NORTH, this);
		prueba.putConstraint(SpringLayout.WEST, descripcion, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, descripcion, 10, SpringLayout.SOUTH, nombre);
		prueba.putConstraint(SpringLayout.WEST, duenio, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, duenio, 10, SpringLayout.SOUTH, direccion);
		prueba.putConstraint(SpringLayout.WEST, direccion, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, direccion, 10, SpringLayout.SOUTH, descripcion);
		prueba.putConstraint(SpringLayout.WEST, codigoPostal, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, codigoPostal, 10, SpringLayout.SOUTH, duenio);
		prueba.putConstraint(SpringLayout.WEST, precio, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, precio, 10, SpringLayout.SOUTH, codigoPostal);
		prueba.putConstraint(SpringLayout.WEST, fianza, 240, SpringLayout.WEST, this);
		prueba.putConstraint(SpringLayout.NORTH, fianza, 10, SpringLayout.SOUTH, precio);
				
		aux.add(botonBloq);
		aux.add(titulo);
		aux.add(botonSig);
		aux.add(botonAnt);
		aux.add(medio);
		aux.add(botonA);
		aux.add(botonR);
		aux.add(botonS);
		aux.add(nombre);
		aux.add(direccion);
		aux.add(descripcion);
		aux.add(duenio);
		aux.add(codigoPostal);
		aux.add(precio);
		aux.add(fianza);
		aux.add(logout);

		
		contenedor.add(aux, BorderLayout.CENTER);
		contenedor.add(medio, BorderLayout.WEST);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setDescripcion(String texto) {
		descripcion.setText(texto);
	}
	
	public void setDescripcionOferta(String texto) {
		descripcion.setText("Descripci�n: " + texto);
	}
	
	public void setDireccionOferta(String texto) {
		direccion.setText("Direcci�n: " + texto);
	}
	
	public void setDue�oOferta(String texto) {
		duenio.setText("Due�o: " + texto);
	}
	
	public void setCodigoPostalOferta(String texto) {
		codigoPostal.setText("Codigo Postal: " + texto);
	}
	
	public JLabel getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal.setText(codigoPostal);
	}

	public void setPrecioOferta(int texto) {
		precio.setText("Precio: " + texto + "�");
	}
	
	public void setFianzaOferta(int texto) {
		fianza.setText("Fianza: " + texto + "�");
	}
	
	public void setPrecioOfertaL(String texto) {
		precio.setText(texto);
	}
	
	public void setFianzaOfertaL(String texto) {
		fianza.setText(texto);
	}
	public JLabel getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre.setText(nombre);
	}

	public JLabel getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(JLabel descripcion) {
		this.descripcion = descripcion;
	}

	public JLabel getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion.setText(direccion);
	}

	public JLabel getDuenio() {
		return duenio;
	}

	public void setDuenio(String duenio) {
		this.duenio.setText(duenio);
	}

	// Para al clicar sobre un boton de aceptar/rechazar/sugerir saber sobre que oferta realizar esta accion en el sistema 
	public void setIDOferta(int id) {
		nombre.setText("Oferta: " + id);
	}
	public int getIDOferta() {
		String s = nombre.getText();
		String def;
		StringTokenizer cmp = new StringTokenizer(s, ": ");
		def = cmp.nextToken();
		try {
			def = cmp.nextToken();
		} catch (NoSuchElementException e){
			System.out.println("Error, no hay id de la oferta");
			return 0;
		}
		return Integer.parseInt(def);
	}
	
	public void setControlador(ActionListener al) {
		botonSig.addActionListener(al);
		botonAnt.addActionListener(al);
		botonBloq.addActionListener(al);
		botonA.addActionListener(al);
		botonR.addActionListener(al);
		botonS.addActionListener(al);
		logout.addActionListener(al);
	}

	public JButton getLogout() {
		return logout;
	}

	public void setLogout(JButton logout) {
		this.logout = logout;
	}

	public JButton getBotonBloq() {
		return botonBloq;
	}

	public void setBotonBloq(JButton botonBloq) {
		this.botonBloq = botonBloq;
	}

	public JButton getBotonSig() {
		return botonSig;
	}

	public void setBotonSig(JButton botonSig) {
		this.botonSig = botonSig;
	}

	public JButton getBotonAnt() {
		return botonAnt;
	}

	public void setBotonAnt(JButton botonAnt) {
		this.botonAnt = botonAnt;
	}

	public JButton getBotonA() {
		return botonA;
	}

	public void setBotonA(JButton botonA) {
		this.botonA = botonA;
	}

	public JButton getBotonR() {
		return botonR;
	}

	public void setBotonR(JButton botonR) {
		this.botonR = botonR;
	}

	public JButton getBotonS() {
		return botonS;
	}

	public void setBotonS(JButton botonS) {
		this.botonS = botonS;
	}
	
	
}
