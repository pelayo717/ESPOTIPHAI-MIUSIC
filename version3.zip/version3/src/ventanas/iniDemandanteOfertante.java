package ventanas;

import java.awt.Container;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class iniDemandanteOfertante extends JFrame {
	
	private static final long serialVersionUID = 2824976528840394089L;
	private JLabel bien = new JLabel("Bienvenido Ofertante y Demandante");
	private String[] bus = {"B�squeda CP","B�squeda Fechas (dd/mm/yyyy)","B�squeda Tipo Oferta", "B�squeda Reservadas", "B�squeda Contratadas"};
	private JPanel aux = new JPanel();
	private JLabel buscar = new JLabel("Caracter�sticas de b�squeda: ");
	private JButton logout = new JButton("Logout");
	private JButton realizar = new JButton("Buscar");
	private JTextField campo = new JTextField("", 10);
	private JButton lista = new JButton("Lista Reservas");
	private JComboBox<String> opciones = new JComboBox<String>(bus);
	private JButton buzon = new JButton("Buz�n");
	private JButton ofertar = new JButton("Ofertar");
	private JButton crearVivienda = new JButton("Crear Vivienda");
	private Container contenedor = this.getContentPane();
	
	
	public iniDemandanteOfertante() {
		super("Book King");
		SpringLayout layout = new SpringLayout();
		aux.setLayout(layout);
		
		/*Ponemos en su sitio el bienvenido y la lista de reservas*/
		layout.putConstraint(SpringLayout.WEST, bien, 20, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, bien, 20, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, lista, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, lista, 40, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, buzon, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, buzon, 70, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, crearVivienda, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, crearVivienda, 100, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, ofertar, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, ofertar, 130, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, logout, 30, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, logout, 270, SpringLayout.NORTH, this);
		
		/* Seteamos los campos para la b�squeda */
		layout.putConstraint(SpringLayout.WEST, buscar, 50, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, buscar, 200, SpringLayout.NORTH, this);		
		layout.putConstraint(SpringLayout.WEST, campo, 10, SpringLayout.EAST, buscar);
		layout.putConstraint(SpringLayout.NORTH, campo, 0, SpringLayout.NORTH, buscar);
		layout.putConstraint(SpringLayout.WEST, opciones, 10, SpringLayout.EAST, campo);
		layout.putConstraint(SpringLayout.NORTH, opciones, -3, SpringLayout.NORTH, campo);
		
		/*Ponemos el boton para proceder a la b�squeda */
		layout.putConstraint(SpringLayout.WEST, realizar, 250, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, realizar, 10, SpringLayout.SOUTH, opciones);
		aux.add(buscar);
		aux.add(opciones);
		aux.add(campo);
		aux.add(realizar);
		aux.add(bien);
		aux.add(lista);
		aux.add(buzon);
		aux.add(crearVivienda);
		aux.add(ofertar);
		aux.add(logout);
		
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setControlador(ActionListener al) {
	
		buzon.addActionListener(al);
		crearVivienda.addActionListener(al);
		ofertar.addActionListener(al);
		realizar.addActionListener(al);
		lista.addActionListener(al);
		opciones.addActionListener(al);
		logout.addActionListener(al);
	}
	
	public String getSeleccionBusqueda() {
		String o = "";
		
		o = (String) opciones.getSelectedItem();
		
		return o;
	}

	public JButton getRealizar() {
		return realizar;
	}

	public void setRealizar(JButton realizar) {
		this.realizar = realizar;
	}

	public JButton getLista() {
		return lista;
	}

	public void setLista(JButton lista) {
		this.lista = lista;
	}

	public String getCampo() {
		return campo.getText();
	}

	public void setCampo(JTextField campo) {
		this.campo = campo;
	}

	public JButton getBuzon() {
		return buzon;
	}

	public void setBuzon(JButton buzon) {
		this.buzon = buzon;
	}

	public JButton getOfertar() {
		return ofertar;
	}
	
	

	public JButton getLogout() {
		return logout;
	}

	public void setLogout(JButton logout) {
		this.logout = logout;
	}

	public void setOfertar(JButton ofertar) {
		this.ofertar = ofertar;
	}

	public JButton getCrearVivienda() {
		return crearVivienda;
	}

	public void setCrearVivienda(JButton crearVivienda) {
		this.crearVivienda = crearVivienda;
	}
	
	
}
