package ventanas;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

public class comentarOferta extends JFrame {
	
	private static final long serialVersionUID = -3899485414068191223L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("Comentarios sobre Oferta: ");
	private JButton respuestas = new JButton("Ver Respuestas");
	private JButton comentar = new JButton("A�adir Comentario");
	private JButton botonSig = new JButton("Siguiente Comentario");
	private JButton botonAnt = new JButton("Comentario Anterior");
	private JButton volver = new JButton("Volver");
	private JLabel coment1 = new JLabel("Comentario usuario: \n");
	private JLabel coment2 = new JLabel("");
	private Container contenedor = this.getContentPane();


	public comentarOferta() {
		super("Book King");
		Font f1 = new Font(null,20, 20);
		titulo.setFont(f1);
		SpringLayout eyy = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		aux.setLayout(eyy);
		
		eyy.putConstraint(SpringLayout.WEST, titulo, 65, SpringLayout.WEST,this);
		eyy.putConstraint(SpringLayout.NORTH, titulo, 10, SpringLayout.NORTH, this);
		
		/*Botones para navegar entre ofertas y realizar acciones sobre las mismas*/
		eyy.putConstraint(SpringLayout.SOUTH, botonSig, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonSig, 10, SpringLayout.EAST, botonAnt);
		eyy.putConstraint(SpringLayout.SOUTH, botonAnt, 310, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.WEST, botonAnt, 120, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.NORTH, comentar, 10, SpringLayout.NORTH, this);
		eyy.putConstraint(SpringLayout.WEST, comentar, 350, SpringLayout.SOUTH, this);
		eyy.putConstraint(SpringLayout.SOUTH, respuestas, -20, SpringLayout.NORTH, botonSig);
		eyy.putConstraint(SpringLayout.EAST, respuestas, 0, SpringLayout.EAST, coment1);
		eyy.putConstraint(SpringLayout.NORTH, volver, 10, SpringLayout.SOUTH, comentar);
		eyy.putConstraint(SpringLayout.WEST, volver, 0, SpringLayout.WEST, comentar);
		
		
		/*Datos de la oferta*/
		eyy.putConstraint(SpringLayout.NORTH, coment1, 50, SpringLayout.SOUTH, titulo);
		eyy.putConstraint(SpringLayout.WEST, coment1, 0, SpringLayout.WEST, titulo);
		eyy.putConstraint(SpringLayout.NORTH, coment2, 10, SpringLayout.SOUTH, coment1);
		eyy.putConstraint(SpringLayout.WEST, coment2, 8, SpringLayout.WEST, coment1);
		
		aux.add(comentar);
		aux.add(titulo);
		aux.add(botonSig);
		aux.add(botonAnt);
		aux.add(respuestas);
		aux.add(coment1);
		aux.add(coment2);
		aux.add(volver);
		
		contenedor.add(aux);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	
	public void setComentario(String cm, String idU) {
		coment1.setText(idU);
		coment2.setText(cm);
		
	}
	
	public void setControlador(ActionListener al) {
		comentar.addActionListener(al);
		botonSig.addActionListener(al);
		botonAnt.addActionListener(al);
		respuestas.addActionListener(al);	
		volver.addActionListener(al);
	}
	
	public JButton getAnadirComentario() {
		return comentar;
	}
	public JButton getVolver() {
		return volver;
	}
	public JButton getSiguienteOferta() {
		return botonSig;
	}
	
	public JButton getOfertaAnterior() {
		return botonAnt;
	}
	
	public JButton getRespuestas() {
		return respuestas;
	}
	
	public JButton getSiguienteComentario() {
		return botonSig;
	}

	public JButton getComentarioAnterior() {
		return botonAnt;
	}
	
}
