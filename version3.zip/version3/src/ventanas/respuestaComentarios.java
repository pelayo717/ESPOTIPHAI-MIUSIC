package ventanas;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class respuestaComentarios extends JFrame {

	private static final long serialVersionUID = 2971797556205130869L;
	private JPanel aux = new JPanel();
	private JLabel titulo = new JLabel("Respuestas del comentario");
	private JButton anterior = new JButton("Anterior respuesta");
	private JButton siguiente = new JButton("Siguiente respuesta");
	private JButton volver = new JButton("Volver");
	private JTextField texto = new JTextField();
	private JLabel respuesta = new JLabel ("Respuesta: ");
	private Container contenedor = this.getContentPane();
	 
	public respuestaComentarios() {
		super("Book king");
		Font f1 = new Font(null, 10, 30);
		titulo.setFont(f1);
		SpringLayout layout = new SpringLayout();
		contenedor.setLayout(new BorderLayout());
		aux.setLayout(layout);
		texto.setPreferredSize(new Dimension(200,50));

		/* Ponemos el t�tulo donde queremos */
		layout.putConstraint(SpringLayout.WEST, titulo, 100, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, titulo, 20, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.WEST, volver, 60, SpringLayout.WEST,this);
		layout.putConstraint(SpringLayout.NORTH, volver, 0, SpringLayout.NORTH,anterior);
		layout.putConstraint(SpringLayout.WEST, anterior, 200, SpringLayout.WEST,this);
		layout.putConstraint(SpringLayout.NORTH, anterior, 400, SpringLayout.NORTH,this);
		layout.putConstraint(SpringLayout.WEST, siguiente, 150, SpringLayout.WEST,this);
		layout.putConstraint(SpringLayout.NORTH, siguiente, 300, SpringLayout.NORTH,this);
		layout.putConstraint(SpringLayout.WEST, anterior, 10, SpringLayout.EAST,siguiente);
		layout.putConstraint(SpringLayout.NORTH, anterior, 300, SpringLayout.NORTH,this);
		layout.putConstraint(SpringLayout.WEST, respuesta, 100, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, respuesta, 100, SpringLayout.NORTH, this);
		
		aux.add(titulo);
		aux.add(anterior);
		aux.add(siguiente);
		aux.add(respuesta);
		aux.add(volver);
		contenedor.add(aux);
		
		/* Establecemos los b�sicos del JFrame */
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,400);
		this.setVisible(true);
	}
	 
	public void setRespuesta(String text) {
		 respuesta.setText("Respuesta: " + text);
	}
	 
	public void setControlador(ActionListener al) {
		anterior.addActionListener(al);
		siguiente.addActionListener(al);
		volver.addActionListener(al);	
	}
	 
	public JButton getAnterior() {
		 return anterior;
	}
	 
	public JButton getVolver() {
		 return volver;
	}
	public JButton getSiguiente() {
		 return siguiente;
	}
}