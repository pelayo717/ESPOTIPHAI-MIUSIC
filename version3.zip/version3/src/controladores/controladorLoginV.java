package controladores;

import java.awt.event.*;

import javax.swing.*;

import sistema.*;
import ventanas.*;

public class controladorLoginV implements ActionListener{

	private loginV login;
	private Sistema sist;
	
	public controladorLoginV(loginV p, Sistema s) {
		this.login = p;
		this.sist = s;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(login.getLogin())) {
			if(sist.esGerente() == true) {
				iniGerente uG = new iniGerente();
				controladorIniGerente cg = new controladorIniGerente(uG, sist, 0);
				JOptionPane.showMessageDialog(null, "Bienvenido Gerente","Holiii", JOptionPane.PLAIN_MESSAGE);
				uG.setControlador(cg);
				uG.setVisible(true);
				login.setVisible(false);
				return;
			}
			if(sist.login(login.getCampoDni().getText(), login.getCampoContra().getText()) == true) {
				if(sist.getUsuarioLogeado().tienePerfilDemandante() == true && sist.getUsuarioLogeado().tienePerfilOfertante() == true) {
					login.setVisible(false);
					iniDemandanteOfertante uDO = new iniDemandanteOfertante();
					controladorIniDemandanteOfertante cdo = new controladorIniDemandanteOfertante(uDO, sist);
					uDO.setControlador(cdo);
					return;
				} else if(sist.getUsuarioLogeado().tienePerfilDemandante() == true) {
					login.setVisible(false);
					iniDemandante uD = new iniDemandante();
					controladorIniDemandante cd = new controladorIniDemandante(uD, sist);
					uD.setControlador(cd);
					return;
				} else if(sist.getUsuarioLogeado().tienePerfilOfertante() == true) {
					login.setVisible(false);
					iniOfertante uO = new iniOfertante();
					controladorIniOfertante co = new controladorIniOfertante(uO, sist);
					uO.setControlador(co);
					return;
				}
			} else {
				JOptionPane.showMessageDialog(login.getLogin(), "Ha introducido credenciales incorrectas","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			}
		}
		if(o1.equals(login.getEntrarSinReg())){
			login.setVisible(false);
			iniSinRegistrarse sr = new iniSinRegistrarse();
			controladorIniSinRegistrarse ctrl = new controladorIniSinRegistrarse(sr, sist);
			sr.setControlador(ctrl);
		}
		return;
	}
		
}
