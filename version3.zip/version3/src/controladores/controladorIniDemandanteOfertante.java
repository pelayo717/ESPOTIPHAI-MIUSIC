package controladores;

import java.awt.event.*;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorIniDemandanteOfertante implements ActionListener{

	private iniDemandanteOfertante iniDemOfer;
	private Sistema sist;
	
	public controladorIniDemandanteOfertante(iniDemandanteOfertante p, Sistema s) {
		this.iniDemOfer = p;
		this.sist = s;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		
		if(o1.equals(iniDemOfer.getLista())) {
			listaReservasDemandante lrd = new listaReservasDemandante();
			controladorListaReservasDemandante clrd = new controladorListaReservasDemandante(lrd, sist, 0);
			lrd.setControlador(clrd);
			iniDemOfer.setVisible(false);
			return;
		}
		
		if(o1.equals(iniDemOfer.getRealizar())) {
			if(iniDemOfer.getSeleccionBusqueda().equalsIgnoreCase("B�squeda CP")) {
				if(iniDemOfer.getCampo().equals("")) {
					JOptionPane.showMessageDialog(null, "Introduce algun t�rmino de b�squeda","Pill�n", JOptionPane.ERROR_MESSAGE);
					return;
				}
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaCP(Integer.parseInt(iniDemOfer.getCampo())),0);
				rbv.setControlador(crbv);
				iniDemOfer.setVisible(false);
				return;
			} else if(iniDemOfer.getSeleccionBusqueda().equalsIgnoreCase("B�squeda Fechas (dd/mm/yyyy)")) {
				if(iniDemOfer.getCampo().equals("")) {
					JOptionPane.showMessageDialog(null, "Introduce algun t�rmino de b�squeda","Pill�n", JOptionPane.ERROR_MESSAGE);
					return;
				}
				StringTokenizer palabra = new StringTokenizer(iniDemOfer.getCampo(), "/");
				String anio, mes, dia;

				dia = palabra.nextToken();
				mes = palabra.nextToken();
				anio = palabra.nextToken();
				
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaFechas(anio, mes, dia),0);
				rbv.setControlador(crbv);
				iniDemOfer.setVisible(false);
				return;
			} else if(iniDemOfer.getSeleccionBusqueda().equalsIgnoreCase("B�squeda Tipo Oferta")) {
				if(iniDemOfer.getCampo().equals("")) {
					JOptionPane.showMessageDialog(null, "Introduce algun t�rmino de b�squeda","Pill�n", JOptionPane.ERROR_MESSAGE);
					return;
				}
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaTipoOferta(iniDemOfer.getCampo()),0);
				rbv.setControlador(crbv);
				iniDemOfer.setVisible(false);
				return;
			} else if(iniDemOfer.getSeleccionBusqueda().equalsIgnoreCase("B�squeda Reservadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaReservadas(),0);
				rbv.setControlador(crbv);
				iniDemOfer.setVisible(false);
				return;
			} else if(iniDemOfer.getSeleccionBusqueda().equalsIgnoreCase("B�squeda Contratadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaContratadas(),0);
				rbv.setControlador(crbv);
				iniDemOfer.setVisible(false);
				return;
			} else if(iniDemOfer.getSeleccionBusqueda().equalsIgnoreCase("B�squeda Pagadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaPagadas(),0);
				rbv.setControlador(crbv);
				iniDemOfer.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(iniDemOfer.getBuzon())) {
			 buzonMensajes bm = new buzonMensajes();
			 controladorBuzonMensajes cbm = new controladorBuzonMensajes(bm, sist,0);
			 bm.setControlador(cbm);
			 iniDemOfer.setVisible(false);
			 return;
		}
		
		if(o1.equals(iniDemOfer.getCrearVivienda())) {
			crearVivienda cv = new crearVivienda();
			controladorCrearVivienda ccv = new controladorCrearVivienda(cv, sist);
			cv.setControlador(ccv);
			iniDemOfer.setVisible(false);
			return;
		}
		
		if(o1.equals(iniDemOfer.getOfertar())) {
			crearOferta co = new crearOferta();
			controladorCrearOferta cco = new controladorCrearOferta(co, sist);
			co.setControlador(cco);
			iniDemOfer.setVisible(false);
			return;
		}
		
		if(o1.equals(iniDemOfer.getLogout())) {
			sist.logout();
			loginV l = new loginV();
			controladorLoginV clv = new controladorLoginV(l, sist);
			l.setControlador(clv);
			iniDemOfer.setVisible(false);
		}
	}
}
