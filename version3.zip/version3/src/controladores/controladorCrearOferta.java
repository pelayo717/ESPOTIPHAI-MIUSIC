package controladores;

import java.awt.event.*;
import java.time.LocalDate;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorCrearOferta implements ActionListener {

	private crearOferta creaOfer;
	private Sistema sist;
	//private ArrayLisy;
	
	public controladorCrearOferta(crearOferta p, Sistema s) {
		this.creaOfer = p;
		this.sist = s;
		for(int i=0; i<((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getViviendas().size();i++) {
			creaOfer.setViviendas(((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getViviendas().get(i).getDescripcionVivienda());
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(creaOfer.getCrearOferta())) {
			creaOfer.getFechaIniRellena().getText();
			
			StringTokenizer palabra = new StringTokenizer(creaOfer.getFechaIniRellena().getText(), "//");
			String anio, mes, dia;
			String vivienda;
			Vivienda v1 = null;

			
				dia = palabra.nextToken();
				mes = palabra.nextToken();
				anio = palabra.nextToken();
				
				LocalDate f1 = LocalDate.of(Integer.parseInt(anio), Integer.parseInt(mes), Integer.parseInt(dia));
				LocalDate f2 = LocalDate.of(9999, 12, 31);

				vivienda = creaOfer.getVivienda();
				creaOfer.getPrecioRelleno().getText();
				for(int i=0; i<((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getViviendas().size();i++) {
					if(((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getViviendas().get(i).getDescripcionVivienda().equals(vivienda)) {
						v1 = ((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getViviendas().get(i);
					}
				}
				if(v1 == null) {
					JOptionPane.showMessageDialog(null, "Error en algun sitio","Pill�n", JOptionPane.ERROR_MESSAGE);
				}
				if(creaOfer.getTipo().equalsIgnoreCase("vacacional")) {
					Vacacional of1 = new Vacacional(f1, f2, Integer.parseInt(creaOfer.getPrecioRelleno().getText()), Integer.parseInt(creaOfer.getFianzaRellena().getText()), false, false, LocalDate.now(), sist.getUsuarioLogeado());
					sist.crearOferta(of1, v1);
					JOptionPane.showMessageDialog(null, "Oferta creada","Crack", JOptionPane.INFORMATION_MESSAGE);
				} else if(creaOfer.getTipo().equalsIgnoreCase("mensual")) {
					AlquilerMensual of1 = new AlquilerMensual(f1, 500, Integer.parseInt(creaOfer.getPrecioRelleno().getText()), Integer.parseInt(creaOfer.getFianzaRellena().getText()), false, false, LocalDate.now(), sist.getUsuarioLogeado());
					sist.crearOferta(of1, v1);
					JOptionPane.showMessageDialog(null, "Oferta creada","Crack", JOptionPane.INFORMATION_MESSAGE);
				}

		}
		
		if(o1.equals(creaOfer.getVolver())) {
			if(sist.getUsuarioLogeado().tienePerfilOfertante() && sist.getUsuarioLogeado().tienePerfilDemandante()) {
				iniDemandanteOfertante ido = new iniDemandanteOfertante();
				controladorIniDemandanteOfertante cido = new controladorIniDemandanteOfertante(ido, sist);
				ido.setControlador(cido);
				creaOfer.setVisible(false);
				return;
			} else if(sist.getUsuarioLogeado().tienePerfilOfertante()) {
				iniOfertante io = new iniOfertante();
				controladorIniOfertante cio = new controladorIniOfertante(io, sist);
				io.setControlador(cio);
				creaOfer.setVisible(false);
				return;
			}
		}
	}
}
