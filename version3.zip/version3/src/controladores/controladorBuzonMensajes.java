package controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorBuzonMensajes implements ActionListener{

	private buzonMensajes buzon;
	private Sistema sist;
	private int l;
	
	public controladorBuzonMensajes(buzonMensajes p, Sistema s, int r) {
		this.buzon = p;
		this.sist = s;
		l = r;
			
		if(((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().isEmpty()) {
			buzon.setEnvio("");
			buzon.setAsunto("No hay mensajes");
			buzon.setMensaje("");
			JOptionPane.showMessageDialog(null, "Est�s mas solo que la una...","No hay mensajes", JOptionPane.ERROR_MESSAGE);
			return;
		} else if(l>((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().size()) {
			buzon.setEnvio("");
			buzon.setAsunto("No hay mensajes");
			buzon.setMensaje("");
			JOptionPane.showMessageDialog(null, "Error","No hay mensajes",JOptionPane.ERROR_MESSAGE);
			return;
		} else if(l<0) {
			buzon.setEnvio("");
			buzon.setAsunto("No hay mensajes");
			buzon.setMensaje("");
			JOptionPane.showMessageDialog(null, "Error","No hay mensajes", JOptionPane.ERROR_MESSAGE);
			return;
		} else if(((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().get(l).equals(null)) {
			buzon.setEnvio("");
			buzon.setAsunto("No hay mensajes");
			buzon.setMensaje("");
			JOptionPane.showMessageDialog(null, "Est�s mas solo que la una...","No hay mensajes", JOptionPane.ERROR_MESSAGE);
		} else {
		
			buzon.setEnvio("De: Gerente");
			buzon.setAsunto("Asunto: Cambios a realizar");
			buzon.setMensaje("Mensaje: " + ((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().get(l));
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(buzon.getBotonSig())) {
			if(l+1>=((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().size()) {
				JOptionPane.showMessageDialog(null, "No hay m�s mensajes","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().get(l+1).equals(null)) {
				JOptionPane.showMessageDialog(null, "No hay mensajes siguientes","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			} else if((l+1)<=((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().size()) {
				buzonMensajes bm = new buzonMensajes();
				controladorBuzonMensajes cbm = new controladorBuzonMensajes(bm, sist, l+1);
				bm.setControlador(cbm);
				buzon.setVisible(false);
				return;
			}else {
				JOptionPane.showMessageDialog(null, "No hay mensajes siguientes","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
		}
		
		if(o1.equals(buzon.getBotonAnt())) {
			if(l-1<0) {
				JOptionPane.showMessageDialog(null, "No hay mensajes anteriores","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(((Ofertante)sist.getUsuarioLogeado().getPerfilOfertante()).getBuzon().get(l-1).equals(null)) {
				JOptionPane.showMessageDialog(null, "No hay mensajes anteriores","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			} else if((l-1)>=0) {
				buzonMensajes bm = new buzonMensajes();
				controladorBuzonMensajes cbm = new controladorBuzonMensajes(bm, sist, l-1);
				bm.setControlador(cbm);
				buzon.setVisible(false);
				return;
			} else {
				JOptionPane.showMessageDialog(null, "No hay mensajes anteriores","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
		if(o1.equals(buzon.getVolver())) {
			if(sist.getUsuarioLogeado().tienePerfilOfertante() && sist.getUsuarioLogeado().tienePerfilDemandante()) {
				iniDemandanteOfertante ido = new iniDemandanteOfertante();
				controladorIniDemandanteOfertante cido = new controladorIniDemandanteOfertante(ido, sist);
				ido.setControlador(cido);
				buzon.setVisible(false);
				return;
			} else if(sist.getUsuarioLogeado().tienePerfilOfertante()) {
				iniOfertante io = new iniOfertante();
				controladorIniOfertante cio = new controladorIniOfertante(io, sist);
				io.setControlador(cio);
				buzon.setVisible(false);
				return;
			}
		}	
	}
}
