package controladores;

import java.awt.event.*;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorIniDemandante implements ActionListener{
	
	private iniDemandante iniDem;
	private Sistema sist;
	
	public controladorIniDemandante(iniDemandante p, Sistema s) {
		this.iniDem = p;
		this.sist = s;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();

		if(o1.equals(iniDem.getLista())) {
			listaReservasDemandante lrd = new listaReservasDemandante();
			controladorListaReservasDemandante clrd = new controladorListaReservasDemandante(lrd, sist, 0);
			lrd.setControlador(clrd);
			iniDem.setVisible(false);
			return;
		}
		
		if(o1.equals(iniDem.getRealizar())) {
			if(iniDem.getTexto().equals("")) {
				JOptionPane.showMessageDialog(null, "Introduce algun t�rmino de b�squeda","Pill�n", JOptionPane.ERROR_MESSAGE);
			}else if(iniDem.getFiltro().equalsIgnoreCase("B�squeda CP")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaCP(Integer.parseInt(iniDem.getTexto())),0);
				rbv.setControlador(crbv);
				iniDem.setVisible(false);
				return;
			} else if(iniDem.getFiltro().equalsIgnoreCase("B�squeda Fechas (dd/mm/yyyy)")) {
				StringTokenizer palabra = new StringTokenizer(iniDem.getTexto(), "/");
				String anio, mes, dia;

				dia = palabra.nextToken();
				mes = palabra.nextToken();
				anio = palabra.nextToken();
				
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaFechas(anio, mes, dia),0);
				rbv.setControlador(crbv);
				iniDem.setVisible(false);
				return;
			} else if(iniDem.getFiltro().equalsIgnoreCase("B�squeda Tipo Oferta")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaTipoOferta(iniDem.getTexto()),0);
				rbv.setControlador(crbv);
				iniDem.setVisible(false);
				return;
			} else if(iniDem.getFiltro().equalsIgnoreCase("B�squeda Reservadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaReservadas(),0);
				rbv.setControlador(crbv);
				iniDem.setVisible(false);
				return;
			} else if(iniDem.getFiltro().equalsIgnoreCase("B�squeda Contratadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaContratadas(),0);
				rbv.setControlador(crbv);
				iniDem.setVisible(false);
				return;
			} else if(iniDem.getFiltro().equalsIgnoreCase("B�squeda Pagadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaPagadas(),0);
				rbv.setControlador(crbv);
				iniDem.setVisible(false);
				return;
			}
			
		}
		if(o1.equals(iniDem.getLogout())) {
			sist.logout();
			loginV l = new loginV();
			controladorLoginV clv = new controladorLoginV(l, sist);
			l.setControlador(clv);
			iniDem.setVisible(false);
		}
	}
}
