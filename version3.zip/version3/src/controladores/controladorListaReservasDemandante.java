package controladores;

import java.awt.event.*;
import java.time.LocalDate;
import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorListaReservasDemandante implements ActionListener{

	private listaReservasDemandante listaRD;
	private Sistema sist;
	private int resActual;
	public controladorListaReservasDemandante(listaReservasDemandante p, Sistema s, int l) {
		this.listaRD = p;
		this.sist = s;
		this.resActual = l;
		
		
		if(((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().isEmpty() == true) {
			listaRD.setIDReserva(0);
			listaRD.setDesc("");
			listaRD.setFechaIni("", "", "");
			listaRD.setFechaFin("","","");
			JOptionPane.showMessageDialog(null, "No hay reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
		} else if(l>((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().size() || l<0) {
			listaRD.setIDReserva(0);
			listaRD.setDesc("");
			listaRD.setFechaIni("", "", "");
			listaRD.setFechaFin("","","");
			JOptionPane.showMessageDialog(null, "No hay reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
			JOptionPane.showMessageDialog(null, "No hay m�s reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
		} else {	
			((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().get(l);			
			listaRD.setIDReserva((resActual+1));
			listaRD.setDesc("Descripci�n: " +((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().get(l).getDescripcion());
			LocalDate Ini = ((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().get(l).getReservaOferta().getFechaIniReserva();
			listaRD.setFechaIni(String.valueOf(Ini.getDayOfMonth()), String.valueOf(Ini.getMonth().getValue()), String.valueOf(Ini.getYear()));
			LocalDate Fin = ((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().get(l).getReservaOferta().getFechaFinReserva();
			listaRD.setFechaFin(String.valueOf(Fin.getDayOfMonth()), String.valueOf(Fin.getMonth().getValue()), String.valueOf(Fin.getYear()));	
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(listaRD.getBotonAnterior()))  {
			if(resActual == 0) {
				JOptionPane.showMessageDialog(null, "No hay m�s reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			}else {
				listaReservasDemandante lrd = new listaReservasDemandante();
				controladorListaReservasDemandante clrd = new controladorListaReservasDemandante(lrd, sist, resActual--);
				lrd.setControlador(clrd);
				listaRD.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(listaRD.getBotonSiguiente()))  {
			if(resActual > ((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().size() ||
					((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().isEmpty()) {
				JOptionPane.showMessageDialog(null, "No hay m�s reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
				return;
			} else {
				listaReservasDemandante lrd = new listaReservasDemandante();
				controladorListaReservasDemandante clrd = new controladorListaReservasDemandante(lrd, sist, resActual++);
				lrd.setControlador(clrd);
				listaRD.setVisible(false);
				return;
			}		
		}
		
		if(o1.equals(listaRD.getBotonAnular())) {
			if(((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().isEmpty()) {
				JOptionPane.showMessageDialog(null, "No hay reserva","Pill�n", JOptionPane.ERROR_MESSAGE);
			} else if(resActual>((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().size() || resActual<0) {
				JOptionPane.showMessageDialog(null, "No hay m�s reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
			} else {
				((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().remove(resActual);
				listaReservasDemandante lrd = new listaReservasDemandante();
				controladorListaReservasDemandante clrd = new controladorListaReservasDemandante(lrd, sist, resActual++);
				lrd.setControlador(clrd);
				listaRD.setVisible(false);
				return;
			}
		}
			
		if(o1.equals(listaRD.getBotonContratar())) {
			if(((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().isEmpty()) {
				JOptionPane.showMessageDialog(null, "No hay reservas","Pill�n", JOptionPane.ERROR_MESSAGE);
			} else if(resActual>((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().size() || resActual<0) {
				JOptionPane.showMessageDialog(null, "No hay m�s reservas","Bruhh", JOptionPane.ERROR_MESSAGE);
			} else {		
				sist.pagarReserva(sist.getUsuarioLogeado(), 
						((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().get(resActual).getDuenioOferta(),
						((Demandante)sist.getUsuarioLogeado().getPerfilDemandante()).getOfertasReservadas().get(resActual), "Pago Reserva");
				listaReservasDemandante lrd = new listaReservasDemandante();
				controladorListaReservasDemandante clrd = new controladorListaReservasDemandante(lrd, sist, resActual++);
				lrd.setControlador(clrd);
				listaRD.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(listaRD.getVol())) {
			if(sist.getUsuarioLogeado().tienePerfilOfertante() && sist.getUsuarioLogeado().tienePerfilDemandante()) {
				iniDemandanteOfertante ido = new iniDemandanteOfertante();
				controladorIniDemandanteOfertante cido = new controladorIniDemandanteOfertante(ido, sist);
				ido.setControlador(cido);
				listaRD.setVisible(false);
				return;
			} else if(sist.getUsuarioLogeado().tienePerfilOfertante()) {
				iniOfertante io = new iniOfertante();
				controladorIniOfertante cio = new controladorIniOfertante(io, sist);
				io.setControlador(cio);
				listaRD.setVisible(false);
				return;
			}
		}
			
		return;	
		
	}
}
