package controladores;

import java.awt.event.*;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorIniOfertante implements ActionListener{
	
	private iniOfertante iniOfer;
	private Sistema sist;
	
	public controladorIniOfertante(iniOfertante p, Sistema s) {
		this.iniOfer = p;
		this.sist = s;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(iniOfer.getRealizar())) {
			if(iniOfer.getTexto().equals("")) {
				JOptionPane.showMessageDialog(null, "Introduce algun t�rmino de b�squeda","Pill�n", JOptionPane.ERROR_MESSAGE);
			}else if(iniOfer.getFiltro().equalsIgnoreCase("B�squeda CP")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaCP(Integer.parseInt(iniOfer.getTexto())),0);
				rbv.setControlador(crbv);
				iniOfer.setVisible(false);
				return;
			} else if(iniOfer.getFiltro().equalsIgnoreCase("B�squeda Fechas (dd/mm/yyyy)")) {
				StringTokenizer palabra = new StringTokenizer(iniOfer.getTexto(), "/");
				String anio, mes, dia;

				dia = palabra.nextToken();
				mes = palabra.nextToken();
				anio = palabra.nextToken();
				
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaFechas(anio, mes, dia),0);
				rbv.setControlador(crbv);
				iniOfer.setVisible(false);
				return;
			} else if(iniOfer.getFiltro().equalsIgnoreCase("B�squeda Tipo Oferta")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaTipoOferta(iniOfer.getTexto()),0);
				rbv.setControlador(crbv);
				iniOfer.setVisible(false);
				return;
			} else if(iniOfer.getFiltro().equalsIgnoreCase("B�squeda Reservadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaReservadas(),0);
				rbv.setControlador(crbv);
				iniOfer.setVisible(false);
				return;
			} else if(iniOfer.getFiltro().equalsIgnoreCase("B�squeda Contratadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaContratadas(),0);
				rbv.setControlador(crbv);
				iniOfer.setVisible(false);
				return;
			} else if(iniOfer.getFiltro().equalsIgnoreCase("B�squeda Pagadas")) {
				resultadosBusquedaVIP rbv = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbv = new controladorResultadosBusquedaVIP(rbv, sist, sist.busquedaPagadas(),0);
				rbv.setControlador(crbv);
				iniOfer.setVisible(false);
				return;
			}
		}
		if(o1.equals(iniOfer.getBuzon())) {
			 buzonMensajes bm = new buzonMensajes();
			 controladorBuzonMensajes cbm = new controladorBuzonMensajes(bm, sist, 0);
			 bm.setControlador(cbm);
			 iniOfer.setVisible(false);
			 return;
		}
		
		if(o1.equals(iniOfer.getCrearVivienda())) {
			crearVivienda cv = new crearVivienda();
			controladorCrearVivienda ccv = new controladorCrearVivienda(cv, sist);
			cv.setControlador(ccv);
			iniOfer.setVisible(false);
			return;
		}
		
		if(o1.equals(iniOfer.getOfertar())) {
			crearOferta co = new crearOferta();
			controladorCrearOferta cco = new controladorCrearOferta(co, sist);
			co.setControlador(cco);
			iniOfer.setVisible(false);
			return;
		}
		if(o1.equals(iniOfer.getLogout())) {
			sist.logout();
			loginV l = new loginV();
			controladorLoginV clv = new controladorLoginV(l, sist);
			l.setControlador(clv);
			iniOfer.setVisible(false);
		}
		
	}
}
