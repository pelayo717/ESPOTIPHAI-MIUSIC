package controladores;

import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;
public class controladorResultadosBusquedaBasica implements ActionListener {

	private resultadosBusquedaBasica resBB;
	private Sistema sist;
	private int ofertaActual;
	private ArrayList<Oferta> resultados;
	private String descripcion;
	
	
	public controladorResultadosBusquedaBasica(resultadosBusquedaBasica p, Sistema s, ArrayList<Oferta> res, int j) {
		this.resBB = p;
		this.sist = s;
		this.ofertaActual = j;
		this.resultados = res;
		
		
		if(resultados.isEmpty() == true) {
			JOptionPane.showMessageDialog(null, "No hay ofertas","Sorry bro...", JOptionPane.ERROR_MESSAGE);

		} else {
			for(int i=0;i<sist.getViviendasSistema().size();i++) {
				for(int h=0;h<sist.getViviendasSistema().get(i).getOfertasVivienda().size();h++) {
					Oferta oferta = sist.getViviendasSistema().get(i).getOfertasVivienda().get(h);
					if(oferta.equals(resultados.get(ofertaActual)))	{
						descripcion = sist.getViviendasSistema().get(i).getDescripcionVivienda();
					}
				}
			}
			resBB.setIDOferta(ofertaActual+1);
			resBB.setDescOferta(descripcion);
			resBB.setFianza(resultados.get(ofertaActual).getFianzaOferta());
			resBB.setValoracion(resultados.get(ofertaActual).getValoracionMedia());
			if(resultados.get(ofertaActual) instanceof Vacacional) {
				resBB.setPrecio("Precio : " + String.valueOf(((Vacacional)resultados.get(ofertaActual)).getPrecioPorDia()));
			} else if(resultados.get(ofertaActual) instanceof AlquilerMensual) {
				resBB.setPrecio("Precio: " + String.valueOf(((AlquilerMensual)resultados.get(ofertaActual)).getPrecioMes()));
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(resBB.getBotonAnterior()))  {
			if(ofertaActual <= 0) {
				JOptionPane.showMessageDialog(null, "No hay ofertas anteriores","Sorry bro...", JOptionPane.ERROR_MESSAGE);
				return;
			}else {
				resultadosBusquedaBasica rbb = new resultadosBusquedaBasica();
				controladorResultadosBusquedaBasica crbb = new controladorResultadosBusquedaBasica(rbb, sist, resultados, ofertaActual-1);
				rbb.setControlador(crbb);
				resBB.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(resBB.getBotonAnterior()))  {
			if(ofertaActual <= 0) {
				JOptionPane.showMessageDialog(null, "No hay ofertas anteriores","Sorry bro...", JOptionPane.ERROR_MESSAGE);
				return;
			}else {
				resultadosBusquedaBasica rbvip = new resultadosBusquedaBasica();
				controladorResultadosBusquedaBasica crbvip = new controladorResultadosBusquedaBasica(rbvip, sist, resultados, ofertaActual-1);
				rbvip.setControlador(crbvip);
				resBB.setVisible(false);;
				return;
			}
		}
		if(o1.equals(resBB.getBotonSiguiente()))  {
			if(ofertaActual >= resultados.size()-1) {
				JOptionPane.showMessageDialog(null, "No hay ofertas siguientes","Sorry bro...", JOptionPane.ERROR_MESSAGE);
				return;
			} else {
				resultadosBusquedaBasica rbb = new resultadosBusquedaBasica();
				controladorResultadosBusquedaBasica crbb = new controladorResultadosBusquedaBasica(rbb, sist, resultados, ofertaActual+1);
				rbb.setControlador(crbb);
				resBB.setVisible(false);
				return;
			}
			}
		if(o1.equals(resBB.getVolver())) {
			iniSinRegistrarse rbb = new iniSinRegistrarse();
			controladorIniSinRegistrarse crbb = new controladorIniSinRegistrarse(rbb, sist);
			rbb.setControlador(crbb);
			resBB.setVisible(false);
		}
		return;
	}
		
	
}
