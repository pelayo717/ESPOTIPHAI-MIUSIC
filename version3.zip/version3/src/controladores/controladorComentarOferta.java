package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorComentarOferta implements ActionListener{
	
	private comentarOferta comentOfer;
	private Sistema sist;
	private int idOferta;
	private int comentActual;
	
	public controladorComentarOferta(comentarOferta p, Sistema s, int IDO, int l) {
		this.comentOfer = p;
		this.sist = s;
		this.idOferta = IDO;
		this.comentActual = l;
		
		if(sist.getOfertasSistema().get(idOferta).getValoracionesOferta().isEmpty()) {
			JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			comentOfer.setComentario("No hay comentarios", "");
		} else if (comentActual < 0 || comentActual > sist.getOfertasSistema().get(idOferta).getValoracionesOferta().size()) {
			JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			comentOfer.setComentario("No hay comentarios", "");
		} else if(sist.getComentarios(sist.getOfertasSistema().get(idOferta)).isEmpty()) {
				JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
				comentOfer.setComentario("No hay comentarios", "");
		}else {
	
			String txt = sist.getComentarios(sist.getOfertasSistema().get(idOferta)).get(comentActual).getComentario();
			comentOfer.setComentario(txt, "Comentario usuario: " + sist.getOfertasSistema().get(idOferta).getValoracionesOferta().get(comentActual).getUsuarioValoracion().getNombre());

//			if(sist.getOfertasSistema().get(idOferta).getValoracionesOferta().get(comentActual) instanceof Comentario) {
//				System.out.println("if dentro");
//				String txt = ((Comentario)sist.getOfertasSistema().get(idOferta).getValoracionesOferta().get(comentActual)).getComentario();
//				comentOfer.setComentario(txt, "Comentario usuario: " + sist.getOfertasSistema().get(idOferta).getValoracionesOferta().get(comentActual).getUsuarioValoracion().getNombre());
//			} else {
//				
//			}	
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(comentOfer.getAnadirComentario())) {
			anadirComentario aC = new anadirComentario();
			controladorAnadirComentario cont = new controladorAnadirComentario(aC, sist, idOferta);
			aC.setControlador(cont);
			return;
		}
		if(o1.equals(comentOfer.getRespuestas())) {
			respuestaComentarios rC = new respuestaComentarios();
			controladorRespuestaComentarios cont = new controladorRespuestaComentarios(rC, sist, idOferta, comentActual);
			rC.setControlador(cont);
			return;
		}
		if(o1.equals(comentOfer.getComentarioAnterior())) {
			if(sist.getOfertasSistema().get(idOferta).getValoracionesOferta().isEmpty() || sist.getValoracionesSistema().isEmpty()) {
				JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			} else if (comentActual < 0 || comentActual > sist.getOfertasSistema().get(idOferta).getValoracionesOferta().size()) {
				JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			} else {
				comentarOferta co = new comentarOferta();
				controladorComentarOferta cco = new controladorComentarOferta(co, sist, idOferta, comentActual--);
				co.setControlador(cco);
				comentOfer.setVisible(false);
				return;
			}
		}
			
		if(o1.equals(comentOfer.getSiguienteComentario())) {
			if(sist.getOfertasSistema().get(idOferta).getValoracionesOferta().isEmpty()) {
				JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			} else if (comentActual < 0 || comentActual > sist.getOfertasSistema().get(idOferta).getValoracionesOferta().size()) {
				JOptionPane.showMessageDialog(comentOfer, "No hay comentarios","Pruebe de nuevo", JOptionPane.ERROR_MESSAGE);
			} else {
				comentarOferta co = new comentarOferta();
				controladorComentarOferta cco = new controladorComentarOferta(co, sist, idOferta, comentActual++);
				co.setControlador(cco);
				comentOfer.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(comentOfer.getVolver())) {
				comentOfer.setVisible(false);
				return;
		}
		
	}
}
