package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorIniGerente implements ActionListener{

	private iniGerente iniG;
	private Sistema sist;
	private int l;
	
	public controladorIniGerente(iniGerente p, Sistema s, int r) {
		this.iniG = p;
		this.sist = s;
		l = r;
		
		
		if(sist.getOfertasAceptar().isEmpty()==true) {
			iniG.setNombre("");
			iniG.setCodigoPostal("");
			iniG.setDireccion("");
			iniG.setDescripcion("");
			iniG.setDuenio("                     No hay ofertas a aceptar");
			iniG.setPrecioOfertaL("");
			iniG.setFianzaOfertaL("");
		} else if(l < 0) {
			iniG.setNombre("");
			iniG.setCodigoPostal("");
			iniG.setDireccion("");
			iniG.setDescripcion("");
			iniG.setDuenio("                     No hay ofertas a aceptar");
			iniG.setPrecioOfertaL("");
			iniG.setFianzaOfertaL("");
		} else if(l>= sist.getOfertasAceptar().size()) {
			iniG.setNombre("");
			iniG.setCodigoPostal("");
			iniG.setDireccion("");
			iniG.setDescripcion("");
			iniG.setDuenio("                     No hay ofertas a aceptar");
			iniG.setPrecioOfertaL("");
			iniG.setFianzaOfertaL("");
		} else {
			for(int i=0; i<sist.getViviendasSistema().size();i++) {
				for(int j=0; j<sist.getViviendasSistema().get(i).getOfertasVivienda().size();j++) {
					if(sist.getViviendasSistema().get(i).getOfertasVivienda().get(j).equals(sist.getOfertasAceptar().get(l))) {
						iniG.setNombre("Oferta :" + (String.valueOf(l+1)));
						iniG.setCodigoPostalOferta(String.valueOf(sist.getViviendasSistema().get(i).getCodigoPostal()));
						iniG.setDireccionOferta(sist.getViviendasSistema().get(i).getDireccionVivienda());
						iniG.setDescripcionOferta(sist.getViviendasSistema().get(i).getDescripcionVivienda());
						iniG.setDue�oOferta(sist.getViviendasSistema().get(i).getDuenio().getNombre() + " " + sist.getViviendasSistema().get(i).getDuenio().getApellidos());
						iniG.setFianzaOferta(sist.getViviendasSistema().get(i).getOfertasVivienda().get(j).getFianzaOferta());
						if(sist.getViviendasSistema().get(i).getOfertasVivienda().get(j) instanceof Vacacional) {
							iniG.setPrecioOferta(((Vacacional)sist.getViviendasSistema().get(i).getOfertasVivienda().get(j)).getPrecioPorDia());
						}
						if(sist.getViviendasSistema().get(i).getOfertasVivienda().get(j) instanceof AlquilerMensual) {
							iniG.setPrecioOferta(((AlquilerMensual)sist.getViviendasSistema().get(i).getOfertasVivienda().get(j)).getPrecioMes());
						}
						break;
					}
				}
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(iniG.getBotonA())) {
			if(sist.getOfertasAceptar().isEmpty() == true || l > sist.getOfertasAceptar().size() || l<0) {
				JOptionPane.showMessageDialog(iniG, "No hay oferta que aceptar","Lista de ofertas vac�a", JOptionPane.ERROR_MESSAGE);
				return;
			} else {
				sist.aceptarOferta(sist.getOfertasAceptar().get(l));
				iniGerente iG = new iniGerente();
				controladorIniGerente cig = new controladorIniGerente(iG, sist, l);
				iG.setControlador(cig);
				iniG.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(iniG.getBotonS())) {
			if(sist.getOfertasAceptar().isEmpty() == true  || l > sist.getOfertasAceptar().size() || l<0) {
				JOptionPane.showMessageDialog(iniG, "No hay oferta sobre la que sugerir cambios","Lista de ofertas vac�a", JOptionPane.ERROR_MESSAGE);
			} else {
				iniGerente iG = new iniGerente();
				controladorIniGerente cig = new controladorIniGerente(iG, sist, l+1);
				iG.setControlador(cig);
				iG.setVisible(false);
				sugerencia sug = new sugerencia();
				controladorSugerencia cs = new controladorSugerencia(sug, sist, sist.getOfertasAceptar().get(l).getDuenioOferta());
				sug.setControlador(cs);
				iniG.setVisible(false);
				iG.setVisible(true);
				return;
			}
		}
		
		if(o1.equals(iniG.getBotonR())) {
			if(sist.getOfertasAceptar().isEmpty() == true  || l > sist.getOfertasAceptar().size() || l<0) {
				JOptionPane.showMessageDialog(iniG, "No hay oferta que rechazar","Lista de ofertas vac�as", JOptionPane.ERROR_MESSAGE);
			} else {
				if(sist.rechazarOferta(sist.getOfertasAceptar().get(l))) {
					JOptionPane.showMessageDialog(iniG, "Pa que vuelva...","Oferta rechazada", JOptionPane.INFORMATION_MESSAGE);
					iniGerente iG = new iniGerente();
					controladorIniGerente cig = new controladorIniGerente(iG, sist, l);
					iG.setControlador(cig);
					iniG.setVisible(false);
					return;
				}
			}
		}
		
		if(o1.equals(iniG.getBotonSig())) {
			if(sist.getOfertasAceptar().isEmpty() == true  || l+1>= sist.getOfertasAceptar().size() || l<0 ) {
				JOptionPane.showMessageDialog(iniG, "No hay siguiente oferta","Lista de ofertas vac�as", JOptionPane.ERROR_MESSAGE);
			} else {
				iniGerente iG = new iniGerente();
				controladorIniGerente cig = new controladorIniGerente(iG, sist, l+1);
				iG.setControlador(cig);
				iniG.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(iniG.getBotonAnt())) {
			if(sist.getOfertasAceptar().isEmpty() == true  || l > sist.getOfertasAceptar().size() || l<0 || l==0) {
				JOptionPane.showMessageDialog(iniG, "No hay oferta anterior","Lista de ofertas vac�as", JOptionPane.ERROR_MESSAGE);
			} else {
				iniGerente iG = new iniGerente();
				controladorIniGerente cig = new controladorIniGerente(iG, sist, l-1);
				iG.setControlador(cig);
				iniG.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(iniG.getBotonBloq())) {
			cambiarTarjetaCredito ctc = new cambiarTarjetaCredito();
			controladorCambiarTarjetaCredito cctc = new controladorCambiarTarjetaCredito(ctc, sist, 0);
			ctc.setControlador(cctc);
			iniG.setVisible(false);
			return;
		}
		
		if(o1.equals(iniG.getLogout())) {
			sist.logout();
			loginV l = new loginV();
			controladorLoginV clv = new controladorLoginV(l, sist);
			l.setControlador(clv);
			iniG.setVisible(false);
		}
	}
}
