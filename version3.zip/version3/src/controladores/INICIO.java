package controladores;

import ventanas.*;
import sistema.*;

public class INICIO {

	public static void main(String[] args) {
		loginV v1 = new loginV();
		Sistema s1 = null;
		s1 = Sistema.getSistema();
		s1.leerSistema();
		s1.leerFicheroUsuarios("usuarios.txt");
		UsuarioRegistrado u = new UsuarioRegistrado("D", "Peter", "Parker", "322223", "X24839204", "3", 1);
		s1.addUsuariosBloqueado(u);
		UsuarioRegistrado u1 = new UsuarioRegistrado("9", "Willy", "Rex", "12313123", "X1232131", "9", 1);
		s1.addUsuariosBloqueado(u1);
		controladorLoginV c1 = new controladorLoginV(v1, s1);
		v1.setControlador(c1);

	}

}
