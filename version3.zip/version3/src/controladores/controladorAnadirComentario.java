package controladores;

import java.awt.event.*;

import sistema.*;
import ventanas.*;

public class controladorAnadirComentario implements ActionListener{

	private anadirComentario p;
	private Sistema sist;
	private int idO;
	
	public controladorAnadirComentario(anadirComentario p, Sistema s, int IDO) {
		this.p = p;
		this.sist = s;
		this.idO = IDO;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(p.getOk())) {
			String texto = p.getComentario();
			Comentario v1 = new Comentario(texto, sist.getUsuarioLogeado());
			sist.getOfertasSistema().get(idO).valorarOferta(v1);
			sist.a�adirValoracion(sist.getOfertasSistema().get(idO), v1);
			p.setVisible(false);
		}
		return;
		
	}
	
}
