package controladores;

import java.awt.event.*;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorResultadosBusquedaVIP implements ActionListener{

	private resultadosBusquedaVIP resVIP;
	private Sistema sist;
	private int ofertaActual;
	private ArrayList<Oferta> resultados;
	private String descripcion;
	private int ofertaEnSist;
	
	public controladorResultadosBusquedaVIP(resultadosBusquedaVIP p, Sistema s, ArrayList<Oferta> res, int l) {
		this.resVIP = p;
		this.sist = s;
		this.ofertaActual = l;
		this.resultados = res;
		
		
		if(resultados.isEmpty() == true) {
			JOptionPane.showMessageDialog(null, "No hay ofertas","Sorry bro...", JOptionPane.ERROR_MESSAGE);
		} else {
			
			for(int i=0;i<sist.getViviendasSistema().size();i++) {
				for(int h=0;h<sist.getViviendasSistema().get(i).getOfertasVivienda().size();h++) {
					Oferta oferta = sist.getViviendasSistema().get(i).getOfertasVivienda().get(h);
					if(oferta.equals(resultados.get(ofertaActual)))	{
						ofertaEnSist = i;
						descripcion = sist.getViviendasSistema().get(i).getDescripcionVivienda();
					}
				}
			}
			resultados.get(ofertaActual).setDescripcion(descripcion);
			resVIP.setIDOferta(ofertaActual+1);
			resVIP.setDescOferta(descripcion);
			resVIP.setFianza(resultados.get(ofertaActual).getFianzaOferta());
			resVIP.setValoracion(resultados.get(ofertaActual).getValoracionMedia());
			if(resultados.get(ofertaActual) instanceof Vacacional) {
				resVIP.setPrecio("Precio : " + String.valueOf(((Vacacional)resultados.get(ofertaActual)).getPrecioPorDia()));
			} else if(resultados.get(ofertaActual) instanceof AlquilerMensual) {
				resVIP.setPrecio("Precio: " + String.valueOf(((AlquilerMensual)resultados.get(ofertaActual)).getPrecioMes()));
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(resVIP.getBotonAnterior()))  {
			if(ofertaActual <= 0) {
				JOptionPane.showMessageDialog(null, "No hay ofertas anteriores","Sorry bro...", JOptionPane.ERROR_MESSAGE);
				return;
			}else {
				resultadosBusquedaVIP rbvip = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbvip = new controladorResultadosBusquedaVIP(rbvip, sist, resultados, ofertaActual-1);
				rbvip.setControlador(crbvip);
				resVIP.setVisible(false);;
				return;
			}
		}
		if(o1.equals(resVIP.getBotonSiguiente()))  {
			if(ofertaActual >= resultados.size()-1) {
				JOptionPane.showMessageDialog(null, "No hay ofertas siguientes","Sorry bro...", JOptionPane.ERROR_MESSAGE);
				return;
			} else {
				resultadosBusquedaVIP rbb = new resultadosBusquedaVIP();
				controladorResultadosBusquedaVIP crbb = new controladorResultadosBusquedaVIP(rbb, sist, resultados, ofertaActual+1);
				rbb.setControlador(crbb);
				resVIP.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(resVIP.getBotonReservar()))  {
				if(resultados.get(ofertaActual).getReservadaOferta() || resultados.get(ofertaActual).getContratadaOferta()) {
					JOptionPane.showMessageDialog(null, "La oferta ya est� reservada :(", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				} else {
					LocalDate l1 = LocalDate.now();
					Reserva r1 = new Reserva(sist.getUsuarioLogeado(), l1);
					sist.reservarOferta(resultados.get(ofertaActual), r1);
					JOptionPane.showMessageDialog(null, "La oferta ha sido reservada con exito", "", JOptionPane.INFORMATION_MESSAGE);
				}
				return;
		}		
		if(o1.equals(resVIP.getBotonComprar())) {
				if(resultados.get(ofertaActual).getContratadaOferta() || resultados.get(ofertaActual).getReservadaOferta()) {
					JOptionPane.showMessageDialog(null, "La oferta ya est� contratada :(", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				} else if(resultados.get(ofertaActual).getReservadaOferta()) {
					JOptionPane.showMessageDialog(null, "La oferta ya est� reservada :(", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}else {
					sist.compraDirectaOferta(resultados.get(ofertaActual), sist.getUsuarioLogeado(), resultados.get(ofertaActual).getDuenioOferta(), "loQueSea");
					JOptionPane.showMessageDialog(null, "La oferta ha sido comprada con exito", "", JOptionPane.INFORMATION_MESSAGE);
				}
				return;
		}
		
		if(o1.equals(resVIP.getBotonValorar())) {
			valoracion vent1 = new valoracion();
			controladorValoracion cont1 = new controladorValoracion(vent1, sist, ofertaActual);
			vent1.setControlador(cont1);
			return;
			
		}
		
		if(o1.equals(resVIP.getBotonComentar())) {
			comentarOferta vent1 = new comentarOferta();
			controladorComentarOferta cont1 = new controladorComentarOferta(vent1, sist, ofertaEnSist, 0);
			vent1.setControlador(cont1);
			return;
			
		}
		
		if(o1.equals(resVIP.getVolver())) {
			if(sist.getUsuarioLogeado().tienePerfilOfertante() && sist.getUsuarioLogeado().tienePerfilDemandante()) {
				iniDemandanteOfertante ido = new iniDemandanteOfertante();
				controladorIniDemandanteOfertante cido = new controladorIniDemandanteOfertante(ido, sist);
				ido.setControlador(cido);
				resVIP.setVisible(false);
				return;
			} else if(sist.getUsuarioLogeado().tienePerfilOfertante()) {
				iniOfertante io = new iniOfertante();
				controladorIniOfertante cio = new controladorIniOfertante(io, sist);
				io.setControlador(cio);
				resVIP.setVisible(false);
				return;
			}else if(sist.getUsuarioLogeado().tienePerfilDemandante()) {
				iniDemandante io = new iniDemandante();
				controladorIniDemandante cio = new controladorIniDemandante(io, sist);
				io.setControlador(cio);
				resVIP.setVisible(false);
				return;
			}
		}
		
		return;		
	}
}