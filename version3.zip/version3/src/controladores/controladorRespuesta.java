package controladores;

import java.awt.event.*;

import sistema.*;
import ventanas.*;

public class controladorRespuesta implements ActionListener {

	private respuesta res;
	private Sistema sist;
	private int l;
	
	public controladorRespuesta(respuesta p, Sistema s, int j) {
		this.res = p;
		this.sist = s;
		this.l = j;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		if(o1.equals(res.getOk())) {
			String texto = res.getRespuesta();
			Comentario c = new Comentario(texto, sist.getUsuarioLogeado());
			sist.getComentarios().get(l).a�adirValoracion(c);
			res.setVisible(false);
		}
		return;
	}
}
