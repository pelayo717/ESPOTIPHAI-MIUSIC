package controladores;

import java.awt.event.*;

import sistema.*;
import ventanas.*;

public class controladorNTarjeta implements ActionListener {

	private nTarjeta numTar;
	private Sistema sist;
	private int indiceUsuarioBloq;
	
	public controladorNTarjeta(nTarjeta p, Sistema s, int idU) {
		this.numTar = p;
		this.sist = s;
		this.indiceUsuarioBloq = idU;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		if(o1.equals(numTar.getOk())) {
			sist.cambiarTarjeta(sist.getUsuariosBloqueados().get(indiceUsuarioBloq), numTar.getTexto());
			cambiarTarjetaCredito vent = new cambiarTarjetaCredito();
			controladorCambiarTarjetaCredito ctrl = new controladorCambiarTarjetaCredito(vent,sist,indiceUsuarioBloq);
			vent.setControlador(ctrl);
			numTar.setVisible(false);
		}
		return;
	}
}
