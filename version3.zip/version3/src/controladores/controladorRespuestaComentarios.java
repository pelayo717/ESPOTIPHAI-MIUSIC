package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorRespuestaComentarios implements ActionListener {

	private respuestaComentarios resComent;
	private Sistema sist;
	private int indComent;
	private int indRes;
	
	
	public controladorRespuestaComentarios(respuestaComentarios p, Sistema s, int indiceComent, int indiceRespuesta) {
		this.resComent = p;
		this.sist = s;
		this.indComent = indiceComent;
		this.indRes = indiceRespuesta;
		
		if(sist.getComentarios().isEmpty()) {
			JOptionPane.showMessageDialog(null, "No hay comentario","xddd", JOptionPane.ERROR_MESSAGE);
		} else if(sist.getComentarios().get(indComent).getValoraciones().isEmpty()) {
			JOptionPane.showMessageDialog(null, "No hay respuesta al comentario","Sorry", JOptionPane.ERROR_MESSAGE);
		} else if(indRes > sist.getComentarios().get(indComent).getValoraciones().size() || indRes<0) {
			JOptionPane.showMessageDialog(null, "No hay respuesta","Sorry", JOptionPane.ERROR_MESSAGE);
			resComent.setRespuesta("No hay comentario");
		} else {
			resComent.setRespuesta(((Comentario)sist.getComentarios().get(indComent).getValoraciones().get(indRes)).getComentario());
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(resComent.getAnterior())) {
			respuestaComentarios rc = new respuestaComentarios();
			controladorRespuestaComentarios crc = new controladorRespuestaComentarios(rc, sist, indComent, indRes-1);
			rc.setControlador(crc);
			resComent.setVisible(false);
			return;
		}
		
		if(o1.equals(resComent.getSiguiente())) {
			respuestaComentarios rc = new respuestaComentarios();
			controladorRespuestaComentarios crc = new controladorRespuestaComentarios(rc, sist, indComent, indRes+1);
			rc.setControlador(crc);
			resComent.setVisible(false);
			return;
		}
		if(o1.equals(resComent.getVolver())) {
		resComent.setVisible(false);
		return;
		}
	}

}