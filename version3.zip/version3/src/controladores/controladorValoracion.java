package controladores;

import java.awt.event.*;

import sistema.*;
import ventanas.*;

public class controladorValoracion implements ActionListener{

	private valoracion val;
	private Sistema sist;
	private int idO;
	
	public controladorValoracion(valoracion p, Sistema s, int IDO) {
		this.val = p;
		this.sist = s;
		this.idO = IDO;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(val.getOk())) {
			Valoracion v1 = new ValoracionNumerica(val.getValoracion(), sist.getUsuarioLogeado());
			sist.getOfertasSistema().get(idO).valorarOferta(v1);
			val.setVisible(false);
		}
		return;
	}
}
