package controladores;

import java.awt.event.*;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorIniSinRegistrarse implements ActionListener{
	private iniSinRegistrarse iniSR;
	private Sistema sist;
	
	public controladorIniSinRegistrarse(iniSinRegistrarse p, Sistema s) {
		this.iniSR = p;
		this.sist = s;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(iniSR.getRealizar())) {
			if(iniSR.getTexto().equals("")) {
				JOptionPane.showMessageDialog(null, "Introduce algun t�rmino de b�squeda","Pill�n", JOptionPane.ERROR_MESSAGE);
			}else if(iniSR.getFiltro().equalsIgnoreCase("B�squeda CP")) {
				resultadosBusquedaBasica rbv = new resultadosBusquedaBasica();
				controladorResultadosBusquedaBasica crbv = new controladorResultadosBusquedaBasica(rbv, sist, sist.busquedaCP(Integer.parseInt(iniSR.getTexto())),0);
				rbv.setControlador(crbv);
				iniSR.setVisible(false);
				return;
			} else if(iniSR.getFiltro().equalsIgnoreCase("B�squeda Fechas (dd/mm/yyyy)")) {
				StringTokenizer palabra = new StringTokenizer(iniSR.getTexto(), "/");
				String anio, mes, dia;

				dia = palabra.nextToken();
				mes = palabra.nextToken();
				anio = palabra.nextToken();
				
				resultadosBusquedaBasica rbv = new resultadosBusquedaBasica();
				controladorResultadosBusquedaBasica crbv = new controladorResultadosBusquedaBasica(rbv, sist, sist.busquedaFechas(anio, mes, dia),0);
				rbv.setControlador(crbv);
				iniSR.setVisible(false);
				return;
			} else if(iniSR.getFiltro().equalsIgnoreCase("B�squeda Tipo Oferta")) {
				resultadosBusquedaBasica rbv = new resultadosBusquedaBasica();
				controladorResultadosBusquedaBasica crbv = new controladorResultadosBusquedaBasica(rbv, sist, sist.busquedaTipoOferta(iniSR.getTexto()),0);
				rbv.setControlador(crbv);
				iniSR.setVisible(false);
				return;
			}
		}
		
		if(o1.equals(iniSR.getReg())) {
			loginV l = new loginV();
			controladorLoginV clv = new controladorLoginV(l, sist);
			l.setControlador(clv);
			iniSR.setVisible(false);
			return;
		}
	}
}

