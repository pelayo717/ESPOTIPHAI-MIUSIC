package controladores;

import java.awt.event.*;

import sistema.*;
import ventanas.*;

public class controladorSugerencia implements ActionListener{

	private sugerencia sug;
	private Sistema sist;
	private UsuarioRegistrado propietarioOferta;
	
	public controladorSugerencia(sugerencia p, Sistema s, UsuarioRegistrado u) {
		this.sug = p;
		this.sist = s;
		propietarioOferta = u;
	}

	@SuppressWarnings("unused")
	@Override
	public void actionPerformed(ActionEvent ae) {
		int i=0;
		Object o1 = ae.getSource();
		
		if(o1.equals(sug.getOk())) {
			for(i=0;i<sist.getUsuariosSistema().size(); i++) {
				if(sist.getUsuariosSistema().get(i).equals(propietarioOferta)) {
					((Ofertante)sist.getUsuariosSistema().get(i).getPerfilOfertante()).anadirSugerenciaBuzon(sug.getTexto().getText());
				}
				
			}
			
			sug.setVisible(false);
		}
	}
}
