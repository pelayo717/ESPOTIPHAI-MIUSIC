package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorCrearVivienda implements ActionListener{

	private crearVivienda vivNueva;
	private Sistema sist;
	
	public controladorCrearVivienda(crearVivienda p, Sistema s) {
		this.vivNueva = p;
		this.sist = s;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(vivNueva.getBotonCrear())) {
			if(vivNueva.getCodigoPostNuevo().getText().equals("") || vivNueva.getDescripcionNueva().getText().equals("") || 
					vivNueva.getDireccionNueva().getText().equals("")) {
				JOptionPane.showMessageDialog(null, "Introduce unos datos anda","Pill�n", JOptionPane.ERROR_MESSAGE);
			}  else {
				int codigoPost = Integer.parseInt(vivNueva.getCodigoPostNuevo().getText());
				String desc = vivNueva.getDescripcionNueva().getText();
				String dir = vivNueva.getDireccionNueva().getText();
				Vivienda v1 = new Vivienda(desc, dir, sist.getUsuarioLogeado(), codigoPost);
				sist.a�adirVivienda(v1);
				JOptionPane.showMessageDialog(null, "Vivienda dada de alta","Felicidades por registrar su vivienda", JOptionPane.PLAIN_MESSAGE);
			}
		}
		
		if(o1.equals(vivNueva.getBotonVolver())) {
			if(sist.getUsuarioLogeado().tienePerfilDemandante() && sist.getUsuarioLogeado().tienePerfilOfertante()) {
				iniDemandanteOfertante ido = new iniDemandanteOfertante();
				controladorIniDemandanteOfertante cido = new controladorIniDemandanteOfertante(ido, sist);
				ido.setControlador(cido);
				vivNueva.setVisible(false);
			}
		}
		
	}
}
