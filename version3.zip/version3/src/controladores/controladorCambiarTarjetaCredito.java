package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import ventanas.*;

public class controladorCambiarTarjetaCredito implements ActionListener {
	
	private cambiarTarjetaCredito ctc;
	private Sistema sist;
	private int l;
	
	public controladorCambiarTarjetaCredito(cambiarTarjetaCredito p, Sistema s, int r) {
		this.ctc = p;
		this.sist = s;
		this.l = r;
		
		if(sist.getUsuariosBloqueados().isEmpty() == true) {
			ctc.setNombreUsuario("");
			ctc.setApellidoUsuario("No hay usuarios bloqueados");
			ctc.setDNIUsuario("");
			ctc.setTarjetaCredito("");
			JOptionPane.showMessageDialog(null, "Error","No hay usuarios bloqueados", JOptionPane.ERROR_MESSAGE);
		} else if(l >= sist.getUsuariosBloqueados().size()) {
			ctc.setNombreUsuario("");
			ctc.setApellidoUsuario("No hay usuarios bloqueados");
			ctc.setDNIUsuario("");
			ctc.setTarjetaCredito("");
			JOptionPane.showMessageDialog(null, "Error","No hay mas usuarios bloqueados", JOptionPane.ERROR_MESSAGE);
		} else if(l<0) {
			ctc.setNombreUsuario("");
			ctc.setApellidoUsuario("No hay usuarios bloqueados");
			ctc.setDNIUsuario("");
			ctc.setTarjetaCredito("");
			JOptionPane.showMessageDialog(null, "Error","No hay mas usuarios bloqueados", JOptionPane.ERROR_MESSAGE);
		}else {
			ctc.setNombreUsuario("Nombre: " + sist.getUsuariosBloqueados().get(l).getNombre());
			ctc.setApellidoUsuario("Apellidos: " + sist.getUsuariosBloqueados().get(l).getApellidos());
			ctc.setDNIUsuario("DNI: " + sist.getUsuariosBloqueados().get(l).getDni());
			ctc.setTarjetaCredito("N�mero tarjeta cr�dito actual: " +sist.getUsuariosBloqueados().get(l).getTarjetaCredito());
		}
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		Object o1 = ae.getSource();
		
		if(o1.equals(ctc.getCambiarTarjetaCredito())) {
			if(sist.getUsuariosBloqueados().isEmpty() == true) {
				JOptionPane.showMessageDialog(null, "Error","No hay usuarios bloqueados", JOptionPane.ERROR_MESSAGE);
			} else if(l >= sist.getUsuariosBloqueados().size()) {
				JOptionPane.showMessageDialog(null, "Error","No hay usuarios bloqueados", JOptionPane.ERROR_MESSAGE);
			} else if(l<0) {
				JOptionPane.showMessageDialog(null, "Error","No hay usuarios bloqueados", JOptionPane.ERROR_MESSAGE);
			}else {
				nTarjeta nt = new nTarjeta();
				controladorNTarjeta cnt = new controladorNTarjeta(nt, sist, l);
				nt.setControlador(cnt);
			}
		}
		
		if(o1.equals(ctc.getBotonSiguienteUsuario())) {
			if((l+1)<sist.getUsuariosBloqueados().size()) {
				cambiarTarjetaCredito ctv = new cambiarTarjetaCredito();
				controladorCambiarTarjetaCredito cctc = new controladorCambiarTarjetaCredito(ctv, sist, l+1);
				ctv.setControlador(cctc);
				ctc.setVisible(false);
				return;
			} else { 
				JOptionPane.showMessageDialog(null, "Error ","No hay siguiente usuario bloqueado", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		if(o1.equals(ctc.getBotonUsuarioAnterior())) {
			if((l-1)>=0) {
				cambiarTarjetaCredito ctv = new cambiarTarjetaCredito();
				controladorCambiarTarjetaCredito cctc = new controladorCambiarTarjetaCredito(ctv, sist, l-1);
				ctv.setControlador(cctc);
				ctc.setVisible(false);
				return;
			} else { 
				JOptionPane.showMessageDialog(null, "Error ","No hay usuario bloqueado anterior", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		if(o1.equals(ctc.getBotonNuevaOferta())) {
			iniGerente ig = new iniGerente();
			controladorIniGerente cig = new controladorIniGerente(ig, sist, 0);
			ig.setControlador(cig);
			ctc.setVisible(false);
			return;
		}
	}
}
